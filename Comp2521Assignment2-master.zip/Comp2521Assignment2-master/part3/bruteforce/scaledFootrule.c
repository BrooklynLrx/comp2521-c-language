#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "footrule.h"
#include <math.h>

#define MAX_URL_LEN     50
#define TRUE 1
#define FALSE 0

int global = 0;
// Function that calculates the rank of a given URL over the total URLs in that file
double rankOverNumURLS(char * file,char * url){
    FILE* fp = fopen(file,"r");
    char store [MAX_URL_LEN];
    int totalURLs =0;
    int rank=0;
    while(fscanf(fp,"%s",store)!=EOF){
        if(strcmp(store,url)==0){
            rank=totalURLs+1;            
        }
        totalURLs++;
    }    
    fclose(fp);
    return (double)rank/totalURLs;
}

int factorial(int n){
    if(n==1){
        return n;
    }
    return factorial(n-1)*n;
}

// Function that the number of URLs in a given file
double numberOfURLs(char * textbuffer){
    FILE* file = fopen(textbuffer,"r");
    char store [MAX_URL_LEN];
    int urls =0;
    while(fscanf(file,"%s",store)!=EOF){   
        urls++;
    }    
    fclose(file);
    return urls;
}


// Function that creates an array and sets all its values to the index it is at
int* arrayNum(int size){
  int* array = malloc(sizeof(int)*size);
  int i = 0;
  while(i<size){
    array[i]=i;
    i++;
  }
  return array;
}

//Given 2 inputs from an array swap its values
void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

//function to put the array in a matrix
void printarray(int arr[], int size,int **combinations)
{
    int i;
    for(i=0; i<size; i++)
    {
        combinations[global][i] = arr[i];
    }
    global++;
}


//Function which stores all perms into a matrix
void permutation(int *arr, int start, int end,int** combinations)
{
    if(start==end)
    {
        printarray(arr, end+1,combinations);
        return;
    }
    int i;
    for(i=start;i<=end;i++)
    {
        //swapping numbers
        swap((arr+i), (arr+start));
        //fixing one first digit
        //and calling permutation on
        //the rest of the digits
        permutation(arr, start+1, end,combinations);
        swap((arr+i), (arr+start));
    }
}


// Function that checks given url exists in given file
int checkURLexistsInFile(char *file,char *URL){
    FILE* open = fopen(file,"r");
    char check[MAX_URL_LEN];
    while(fscanf(open,"%s",check)!=EOF){
        if(strcmp(check,URL)==0){
            fclose(open);
            return TRUE;
        }
    
    }
    fclose(open);
    return FALSE;
}

// Function that creates a matrix with all values initialised to 0
double **createMatrix(int nRows, int nCols) {
    double **matrix = malloc(sizeof(double*)*nRows);
    int i;
    for(i=0;i<nRows;i++){
        matrix[i] = malloc(sizeof(double)*nCols);
    }
    
    // Initialise everything in the matrix to 0
    int row = 0, col = 0;
    while(row < nRows){
        col = 0;
        while(col < nCols){
            matrix[row][col]=0;
            col++;
        }        
        row++;
    }    
    return matrix;
}

// Function that sums the toBeCalculated matrix into the pScore Matrix
void sumToBeCalculatedMatrix(double **toBeCalculated, int nRows, int nCols, int p, double **pScoreMatrix){
    double scoreSum;
    int j, k;
    // Sum the toBeSummed matrix into pScoreMatrix
    for(j=0;j<nRows;j++){
        scoreSum = 0;
        for(k=0;k<nCols;k++){
            scoreSum = scoreSum + toBeCalculated[j][k];
            pScoreMatrix[j][p-1]=scoreSum;
        }
    }      
}

// Function that frees an int* matrix
void Free_matrix(int** matrix , int rows){
    int i;
 
    for(i=0;i<rows;i++){
        free(matrix[i]);
    
    }
}


// Function that frees a char* matrix
void Free_Char_matrix(char** matrix , int rows){
    int i;
 
    for(i=0;i<rows;i++){
        free(matrix[i]);
    
    }


}

// Function that frees a double* matrix
void Free_doub_matrix(double** matrix , int rows){
    int i;
 
    for(i=0;i<rows;i++){
        free(matrix[i]);
    
    }


}


// Function that fills the pScore Matrix
void fillPScoreMatrix (double **toBeCalculated, double **pScoreMatrix,
                       urlnode currFile, urlnode firstFile, 
                       int numURLs, int numFiles, char **arr) {
    
    int filesChecked = 0;
    double wcpScore = 0, fileScore = 0, pScore = 0;
    int p = 0, i = 0;
                    
    // For each p rank  
    for(p = 1; p <= numURLs; p++){
        
        // For each file
        filesChecked = 0;
        for(currFile = firstFile; currFile!=NULL; currFile = currFile->next){           
            
            // For each URL in C
            for (i = 0; i < numURLs; i++){
                
                //Check url exists in open file
                if(checkURLexistsInFile(currFile->store,arr[i])){
                   
                    // Calculate the W(c,p) score for current file
                    //abs (fileRank/TotalurlInFiles - Prank/numberFiles)
                    fileScore = rankOverNumURLS(currFile->store, arr[i]);
                    pScore = p/(double)numURLs;
                    wcpScore = fabs(fileScore-pScore);

                    // Store score into the corresponding column for 
                    // the file in the TBSummed array
                    toBeCalculated[i][filesChecked] = wcpScore;
                }
            }
            filesChecked++;
        }        
        sumToBeCalculatedMatrix(toBeCalculated, numURLs, numFiles, p, pScoreMatrix);              
   }
}

double minimumScore(int**combinations,int nCom,int nURLs,double** matrix,int *Finalsequence){
    int i =0;
    int j =0;
    int Finalindex = 0;
    double final = 100;
    double score = 0;
    for(i=0;i<nCom;i++){
        for(j=0;j<nURLs;j++){
            score = score + matrix[combinations[i][j]][j];
        }
        if(score<final){
            Finalindex = i;
            final = score;
        }
        score = 0;
    
    }
    for(i=0;i<nURLs;i++){
        Finalsequence[i] = combinations[Finalindex][i];
    
    }
    return final;
}


int main (int argc ,char** argv){
    //Check there are ranking files supplied
    if (argc < 2) {
        printf("No files supplied\n");
        abort();
    }
    
    // Put the files into a linked list
    int i = 2;
    urlnode firstFile = createNode(argv[1],0);    
    urlnode currFile = firstFile;    
    while(i<argc){
        currFile->next = createNode(argv[i],i-1);
        currFile = currFile->next;
        i++;
    }
    
    // Put the URLs into a BSTree with unique nodes
    FILE* textbuffer;
    BSTree set = NULL;
    char holder[50];
    currFile = firstFile;
    while(currFile!=NULL){      
        textbuffer = fopen(currFile->store,"r");
        while(fscanf(textbuffer,"%s",holder)!=EOF){            
            set = BSTreeInsert(set,holder);        
        }
        fclose(textbuffer);
        currFile = currFile->next;
    }
    int numURLs = BSTreeNumNodes(set);   
    int numFiles = argc-1;
    
    // Put the URLs into a char array called arr
    // This represents the union of URLs, C
    char **arr = malloc(sizeof(char*)*numURLs);    
    AddToArray(set,arr,0);

    // Initialise the toBeCalculated matrix and the pScoreMatrix
    double **toBeCalculated = createMatrix(numURLs, numFiles);      
    double **pScoreMatrix = createMatrix(numURLs, numURLs);
    
    // Fill the pScore matrix
   fillPScoreMatrix (toBeCalculated, pScoreMatrix, currFile, firstFile,
                      numURLs, numFiles, arr);
       
    /* Debugging prints
    printf("File is %s\n",currFile->store);
    printf("URL = %s\n",arr[i]);
    printf("filescore = %f\n",fileScore); 
    printf("pScore is %f \n",pScore);
                        
    printf("i is %d\n");
    printf("filesChecked is %d\n",filesChecked);
    */
    int **storeCombination = malloc(sizeof(int*)*factorial(numURLs));
    for(i=0;i<factorial(numURLs);i++){
        storeCombination[i] = malloc(sizeof(int)*numURLs);
    
    }
    int * Finalsequence = malloc(sizeof(int)*numURLs);
    int* sequence = arrayNum(numURLs);
    permutation(sequence, 0, numURLs-1,storeCombination);
    double Fscore = minimumScore(storeCombination,factorial(numURLs),numURLs,pScoreMatrix,Finalsequence);
    printf("%f\n",Fscore);
    
    for(i=0;i<numURLs;i++){
        printf("%s\n",arr[Finalsequence[i]]);
    
    } 
    
    Free_matrix(storeCombination , factorial(numURLs));
    free(storeCombination);
    free(Finalsequence);
    Free_Char_matrix(arr,numURLs);
    free(arr);
    dropBSTree(set);
    Freenode(firstFile);
    Free_doub_matrix(toBeCalculated,numURLs);
    free(toBeCalculated);
    Free_doub_matrix(pScoreMatrix,numURLs);
    free(pScoreMatrix);
    free(sequence);
    // Prints pScoreMatrix
  /*  int j = 0;
    for(i=0;i<numURLs;i++){
        for(j=0;j<numURLs;j++){
            printf("%f ",pScoreMatrix[i][j]);
        }
    printf("\n");
    }
   
    */
    
    /* Prints toBeCalcMatrix
    i =0 ;
    int z =0;
    while(i<numURLs){
        while(z<numFiles){
            printf("%f ",toBeCalculated[i][z]);
            z++;
        }
        printf("\n");
        i++;
        z=0;
    }
    */
    
}

