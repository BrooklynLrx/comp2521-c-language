#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "footrule.h"
#include <math.h>

#define MAX_URL_LEN     50
#define TRUE 1
#define FALSE 0


// ******************* Section: Function Prototypes *******************

double **createMatrix(int nRows, int nCols);
void resetMatrix(double **matrix, int nRows, int nCols);
void fillPScoreMatrix (double **toBeCalculated, double **pScoreMatrix,
                       urlnode currFile, urlnode firstFile, 
                       int numURLs, int numFiles, char **arr);
int checkURLexistsInFile(char *file,char *URL);
double rankOverNumURLS(char * file,char * url);
double numberOfURLs(char * textbuffer);
void sumToBeCalculatedMatrix(double **toBeCalculated, int nRows, int nCols, 
                             int p, double **pScoreMatrix);
double** copyMatrix(double** matrix,int rows, int cols);
void subtractMinRows(double **pScoreMatrix, int nRows, int nCols);
void subtractMinCols(double **pScoreMatrix, int nRows, int nCols);
int findMinLines(double **pScoreMatrix, double **markedMatrix,
                 double **linesMatrix, int nRows, int nCols);
int zerosAllMarked(double **pScoreMatrix, double **markedMatrix,
                   int nRows, int nCols);
int allZerosMarkedinCol(double **pScoreMatrix, double **markedMatrix,
                        int col, int nRows);
int allZerosMarkedinRow(double **pScoreMatrix, double **markedMatrix,
                        int row, int nCols);
void adjustPScoreMatrix(double **pScoreMatrix, double **linesMatrix,
                        double **markedMatrix, int nRows, int nCols);
void getFinalRank(int *finalRank, double **markedMatrix, 
                  int nRows, int nCols);
int marksExist(double **markedMatrix, int nRows, int nCols);
int onlyZeroInRow(double **markedMatrix, int nCols, int row, int col);
int onlyZeroInCol(double **markedMatrix, int nRows, int row, int col); 
void resetRowCol(double **markedMatrix, int row, int col,
                 int nRows, int nCols);
void printFinalScore(int *finalRank, double **originalpScores, int numURLs);
void printFinalRank(int *finalRank, int numURLs, char **arr);
// void printMatrix (double **matrix, int nRows, int nCols);


// ************************** Section: Main **************************
/*
    Smart Algorithm Strategy (using the Hungarian Method):
    
    Part One: 
    Set up the p Scores Matrix to apply the Hungarian Method,
    where each row represents an URL and each column, a potential p-rank
    
        1) Get URLs from the supplied ranking files and put into BSTree
           (only unique values added)
        2) Put the BSTreeNodes into a char array
        3) For the possible p ranks from 1 to the number of URLs,
            a) get the summed W(c,p) score for each file, storing this
               in a temporary "toBeCalculated" array
            b) Sum the "toBeCalculated" array for the given p-value
               and URL
            c) Insert the sum into the p Scores Matrix
    
    Part Two: 
    Find the min in each column and row using the Hungarian Method
    
        1) Find the minimum in each row and subtract it from all other
           numbers in the row
        2) After this, repeat for columns
        3) Find the minimum number of lines required to pass through
           all the 0s
            a) If the min < num URLs
               - Find the minimum in the cells not covered by the lines
               - Subtract this from all other cells not covered
               - Add this to all cells that are at an intersection of 2
                 lines
               - Repeat step 3
            b) If min = numURLs
               Extract the ranking
*/


void freeCharArray(char **arr, int nRows) {
    int i;
    for (i = 0; i < nRows; i++) {
        free(arr[i]);
    }
    free(arr);
}

void freeMatrix(double **matrix, int nRows) {
    int i;
    for (i = 0; i < nRows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

int main (int argc ,char** argv){
    //Check there are ranking files supplied
    if (argc < 2) {
        printf("No files supplied\n");
        abort();
    }
    
    // Put the files into a linked list
    int i = 2;
    urlnode firstFile = createNode(argv[1],0);    
    urlnode currFile = firstFile;    
    while(i<argc){
        currFile->next = createNode(argv[i],i-1);
        currFile = currFile->next;
        i++;
    }
    
    // Put the URLs into a BSTree with unique nodes
    FILE* textbuffer;
    BSTree set = NULL;
    char holder[50];
    currFile = firstFile;
    while(currFile!=NULL){      
        textbuffer = fopen(currFile->store,"r");
        while(fscanf(textbuffer,"%s",holder)!=EOF){            
            set = BSTreeInsert(set,holder);        
        }
        fclose(textbuffer);
        currFile = currFile->next;
    }
    int numURLs = BSTreeNumNodes(set);   
    int numFiles = argc-1;
    
    // Put the URLs into a char array called arr
    // This represents the union of URLs, C
    char **arr = malloc(sizeof(char*)*numURLs);
    AddToArray(set,arr,0);
    
    // Initialise the toBeCalculated matrix and the pScoreMatrix
    double **toBeCalculated = createMatrix(numURLs, numFiles);      
    double **pScoreMatrix = createMatrix(numURLs, numURLs);
    
    // Fill the pScore matrix and then make a copy
    fillPScoreMatrix(toBeCalculated, pScoreMatrix, currFile, firstFile,
                     numURLs, numFiles, arr);
    double **originalpScores = copyMatrix(pScoreMatrix,numURLs, numURLs);
    
    // First subtract the minimum from each row in the pScore matrix  
    subtractMinRows(pScoreMatrix, numURLs, numURLs);
    
    // Then subtract the minimum from each column in the pScore matrix    
    subtractMinCols(pScoreMatrix, numURLs, numURLs);     
    
    // Find the minimum number of lines required to go through the pScore
    // matrix after the two subtractions
    double **markedMatrix = createMatrix(numURLs,numURLs);
    double **linesMatrix = createMatrix(numURLs,numURLs);
    int minLines = findMinLines(pScoreMatrix, markedMatrix, linesMatrix,
                                numURLs, numURLs);
    
    while (minLines != numURLs) {
        adjustPScoreMatrix(pScoreMatrix, linesMatrix, markedMatrix,    
                           numURLs, numURLs);        
        minLines = findMinLines(pScoreMatrix, markedMatrix, linesMatrix, 
                                numURLs, numURLs);
    }
    
    // Now the minimum number of lines is the same as the numURLs
    // We can now find the optimal ranking and store into an array
    // With finalRank[urlIndex][pRank]
    int *finalRank = malloc(numURLs*sizeof(int));    
    getFinalRank(finalRank, markedMatrix, numURLs, numURLs);    
    
    printFinalScore(finalRank,originalpScores, numURLs);
    printFinalRank(finalRank, numURLs, arr);
    
    // Free malloced memory
    freeBSTree(set);
    freeURLNode(firstFile);
    freeCharArray(arr, numURLs);
    freeMatrix(toBeCalculated, numURLs);
    freeMatrix(pScoreMatrix, numURLs);
    freeMatrix(originalpScores, numURLs);
    freeMatrix(markedMatrix, numURLs);
    freeMatrix(linesMatrix, numURLs);
    free(finalRank);
}

// ************************ Section: Functions ************************


// Function that creates a matrix with all values initialised to 0
double **createMatrix(int nRows, int nCols) {
    double **matrix = malloc(sizeof(double*)*nRows);
    int i;
    for(i=0;i<nRows;i++){
        matrix[i] = malloc(sizeof(double)*nCols);
    }
    
    // Initialise everything in the matrix to 0
    resetMatrix(matrix, nRows, nCols);    
    return matrix;
}

// Function that sets all matrix values to 0
void resetMatrix(double **matrix, int nRows, int nCols) {    
    int row = 0, col = 0;
    while(row < nRows){
        col = 0;
        while(col < nCols){
            matrix[row][col]=0;
            col++;
        }        
        row++;
    }    
}

// Function that fills the pScore Matrix
void fillPScoreMatrix (double **toBeCalculated, double **pScoreMatrix,
                       urlnode currFile, urlnode firstFile, 
                       int numURLs, int numFiles, char **arr) {
    
    int filesChecked = 0;
    double wcpScore = 0, fileScore = 0, pScore = 0;
    int p = 0, i = 0;
                    
    // For each p rank  
    for(p = 1; p <= numURLs; p++){
        
        // For each file
        filesChecked = 0;
        for(currFile = firstFile; currFile!=NULL; currFile = currFile->next){           
            
            // For each URL in C
            for (i = 0; i < numURLs; i++){
                
                //Check url exists in open file
                if(checkURLexistsInFile(currFile->store,arr[i])){
                   
                    // Calculate the W(c,p) score for current file
                    //abs (fileRank/TotalurlInFiles - Prank/numberFiles)
                    fileScore = rankOverNumURLS(currFile->store, arr[i]);
                    pScore = p/(double)numURLs;
                    wcpScore = fabs(fileScore-pScore);

                    // Store score into the corresponding column for 
                    // the file in the TBSummed array
                    toBeCalculated[i][filesChecked] = wcpScore;
                }
            }
            filesChecked++;
        }        
        sumToBeCalculatedMatrix(toBeCalculated, numURLs, numFiles, p, pScoreMatrix);              
   }
}

// Function that checks given url exists in given file
int checkURLexistsInFile(char *file,char *URL){
    FILE* open = fopen(file,"r");
    char check[MAX_URL_LEN];
    while(fscanf(open,"%s",check)!=EOF){
        if(strcmp(check,URL)==0){
            fclose(open);
            return TRUE;
        }    
    }
    fclose(open);
    return FALSE;
}

// Function that calculates the rank of a given URL over the total URLs in that file
double rankOverNumURLS(char * file,char * url){
    FILE* fp = fopen(file,"r");
    char store [MAX_URL_LEN];
    int totalURLs =0;
    int rank=0;
    while(fscanf(fp,"%s",store)!=EOF){
        if(strcmp(store,url)==0){
            rank=totalURLs+1;            
        }
        totalURLs++;
    }    
    fclose(fp);
    return (double)rank/totalURLs;
}

// Function that the number of URLs in a given file
double numberOfURLs(char * textbuffer){
    FILE* file = fopen(textbuffer,"r");
    char store [MAX_URL_LEN];
    int urls =0;
    while(fscanf(file,"%s",store)!=EOF){   
        urls++;
    }    
    fclose(file);
    return urls;
}

// Function that sums the toBeCalculated matrix into the pScore Matrix
void sumToBeCalculatedMatrix(double **toBeCalculated, int nRows, int nCols, 
                             int p, double **pScoreMatrix){
    double scoreSum;
    int j, k;
    // Sum the toBeSummed matrix into pScoreMatrix
    for(j=0;j<nRows;j++){
        scoreSum = 0;
        for(k=0;k<nCols;k++){
            scoreSum = scoreSum + toBeCalculated[j][k];
            pScoreMatrix[j][p-1]=scoreSum;
        }
    }      
}

// Function that copies a given matrix
double** copyMatrix(double** matrix,int rows, int cols) {
    double** copy = malloc(sizeof(double*)*rows);
    int i = 0;
    int j = 0;
    while(i<rows){
        copy[i] = malloc(sizeof(double)*cols);
        i++;
    }    
    for(i = 0; i < rows; i++){
        for(j = 0; j < cols; j++){
            copy[i][j]=matrix[i][j];        
        }
        j=0;    
    }
    return copy;
}


// Function that subtracts the min of each row from the row in pScoreMatrix
void subtractMinRows(double **pScoreMatrix, int nRows, int nCols) {
    int i,j;
    double min;
    
    // For each row
    for (i = 0; i < nRows; i++) {
        
        // Set the minimum in that row to be the first one
        min = pScoreMatrix[i][0];
        // Then check the following columns in that row for smaller min
        for (j = 0; j < nCols; j++) {
            if (pScoreMatrix[i][j] < min) min = pScoreMatrix[i][j];
        }
        
        // Now that we have found the min in the row
        // We need to subtract it from the values in the row
        for (j = 0; j < nCols; j++) {
            pScoreMatrix[i][j] -= min;
        }
    }
}

// Function that subtracts the min of each row from the row in pScoreMatrix
void subtractMinCols(double **pScoreMatrix, int nRows, int nCols) {
    int i,j;
    double min;
    
    // For each column
    for (j = 0; j < nCols; j++) {
        
        // Set the minimum in that col to be the first one
        min = pScoreMatrix[0][j];
        
        // Then check the following rows in that col for smaller min
        for (i = 0; i < nRows; i++) {
            if (pScoreMatrix[i][j] < min) min = pScoreMatrix[i][j];
        }
        
        // Now that we have found the min in the col
        // We need to subtract it from the values in the col
        for (i = 0; i < nRows; i++) {
            pScoreMatrix[i][j] -= min;
        }
    }
}

// Function that finds the minimum number of lines required
// pass through all the 0s in pScoreMatrix;
int findMinLines(double **pScoreMatrix, double **markedMatrix,
                 double **linesMatrix, int nRows, int nCols) {
    int i, j, max;
    int trackerRow = 0, count = 0, lines = 0;
    resetMatrix(markedMatrix, nRows, nCols);
    resetMatrix(linesMatrix, nRows, nCols);
    
    // printf("\nEntering the findMinLines function\n");
    
    while (!zerosAllMarked(pScoreMatrix, markedMatrix, nRows, nCols)) { 
        max = 0; 
        // Find the largest 0 count in the rows
        for (i = 0; i < nRows; i++) {            
            count = 0;
            for (j = 0; j < nCols; j++) {                
                if (pScoreMatrix[i][j] == 0) {
                    count++;
                }
            }            
            if (count > max &&
                !allZerosMarkedinRow(pScoreMatrix,markedMatrix,
                                     i,nCols)) {
                max = count;
                trackerRow = i;
            }
        }

        // Find the largest 0 count in the columns
        for (j = 0; j < nCols; j++) {
            count = 0;
            for (i = 0; i < nRows; i++) {
                if (pScoreMatrix[i][j] == 0) {
                    count++;
                }
            }
            // printf("The count for column %d is %d\n",j,count);
                        
            if (count > max &&
                !allZerosMarkedinCol(pScoreMatrix,markedMatrix,
                                     j,nRows)) {
                max = count;
                trackerRow = j + nRows + 1;
            }
        }
        // printf("max is %d\n", max);
        // printf("trackerRow is %d\n", trackerRow);
        
        // Now we have found the line going through the most unmarked 0s
        // If it is a column
        if (trackerRow > nRows) {
            // printf("It is a column\n");
            int trackerCol = trackerRow - nRows - 1;
            for (i = 0; i < nRows; i++) {
                if (pScoreMatrix[i][trackerCol] == 0 &&
                    markedMatrix[i][trackerCol] == 0) {
                    markedMatrix[i][trackerCol] = 1;
                }
                linesMatrix[i][trackerCol]++;
            }
            
        // If it is a row
        } else {
            // printf("It is a row\n");
            for (j = 0; j < nCols; j++) {
                if (pScoreMatrix[trackerRow][j] == 0 &&
                    markedMatrix[trackerRow][j] == 0) {
                    markedMatrix[trackerRow][j] = 1;
                }
                linesMatrix[trackerRow][j]++;
            }            
        }
        lines++;                        
    }
    
    /*
    printf("pScore Matrix: \n");
    printMatrix(pScoreMatrix, nRows, nCols);
    
    printf("\nMarked Matrix: \n");
    printMatrix(markedMatrix, nRows, nCols);
    
    printf("\nLines Matrix: \n");
    printMatrix(linesMatrix, nRows, nCols);
    */
    // printf("lines is %d\n",lines);
    return lines;
}

// Function that checks if all the zeros in pScoreMatrix have been marked
// in markedMatrix
int zerosAllMarked(double **pScoreMatrix, double **markedMatrix,
                   int nRows, int nCols) {
    int i, j;
    for (i = 0; i < nRows; i++) {
        for (j = 0; j < nCols; j++) {
            if (pScoreMatrix[i][j] == 0 &&
                markedMatrix[i][j] == 0) {
                return FALSE;
            }
        }                    
    }
    return TRUE;    
}

// Function that checks if all zeros have been marked for a given row
int allZerosMarkedinRow(double **pScoreMatrix, double **markedMatrix,
                        int row, int nCols) {
    int i;
    for (i = 0; i < nCols; i++) {
        if (pScoreMatrix[row][i] == 0 &&
            markedMatrix[row][i] != 1) {
            return FALSE;    
        }
    }                    
    return TRUE;                      
}

// Function that checks if all zeros have been marked for a given column
int allZerosMarkedinCol(double **pScoreMatrix, double **markedMatrix,
                        int col, int nRows) {
    int j;
    for (j = 0; j < nRows; j++) {
        if (pScoreMatrix[j][col] == 0 &&
            markedMatrix[j][col] != 1) {
            return FALSE;    
        }
    }                    
    return TRUE; 
}

void adjustPScoreMatrix(double **pScoreMatrix, double **linesMatrix,
                        double **markedMatrix, int nRows, int nCols) {
    /*
    printf("\nBefore adjustments the pScoreMatrix is\n");
    printMatrix(pScoreMatrix, nRows, nCols);
    
    printf("\nAnd linesMatrix is\n");
    printMatrix(linesMatrix, nRows, nCols);
    */
    int i, j;
    double min = 0;
    // First, find the minimum outside the lines
    for (i = 0; i < nRows; i++) {
        for (j = 0; j < nCols; j++) {
            if (linesMatrix[i][i] == 0 &&
                (min == 0 || pScoreMatrix[i][j] < min)) {                
                min = pScoreMatrix[i][j];  
            }
        }
    }

    
    // Now, subtract this from cells outside the lines
    // and add to cells where overlaps occur
    for (i = 0; i < nRows; i++) {
        for (j = 0; j < nCols; j++) {
            if (linesMatrix[i][j] == 0) {                
                pScoreMatrix[i][j] -= min;
                // Update marksMatrix
                if(pScoreMatrix[i][j] == 0) {
                    markedMatrix[i][j] = 1;
                } 
            } else if (linesMatrix[i][j] > 1) {
                pScoreMatrix[i][j] += min;
                markedMatrix[i][j] = 0;
            }
        }
    }
    /*
    printf("\nAfter adjustments the pScoreMatrix is\n");
    printMatrix(pScoreMatrix, nRows, nCols);
    */
}

// Function that gets the final P Rank
void getFinalRank(int *finalRank, double **markedMatrix, 
                  int nRows, int nCols) {  
    int i,j;
    int found = TRUE;
    
    /*
    printf("\nEntering getFinalRank\nThe Marked Matrix is\n");
    printMatrix(markedMatrix, nRows, nCols);
    */

    // If no more 1s or found = FALSE, this means we have either
    // exhausted unique values or have finished the matrix
    while (found == TRUE && marksExist(markedMatrix, nRows, nCols)){

        found = FALSE;
        // Check each cell to see if it is the only one in its row or column

        for (i = 0; i < nRows; i++) {
            for (j = 0; j < nCols; j++) {               
                
                /*
                printf("\n");
                printMatrix(markedMatrix, nRows, nCols);                
                printf("markedMatrix[%d][%d] is %lf\n", i, j, markedMatrix[i][j]);
                printf("only zero in column? %d\n", onlyZeroInCol(markedMatrix,nRows,i,j));
                printf("only zero in row? %d\n", onlyZeroInRow(markedMatrix,nCols,i,j));
                */
                
                if (markedMatrix[i][j] == TRUE &&
                    (onlyZeroInCol(markedMatrix,nRows,i,j) ||
                    onlyZeroInRow(markedMatrix,nCols,i,j))) {
                    // printf("Entered\n");
                    
                    // Unique mark found
                    found = TRUE;   
                    // Store answer in pArray
                    finalRank[i] = j;
                    // Set the entire row and column to 0 in markedMatrix
                    resetRowCol(markedMatrix, i, j, nRows, nCols);                  
                    break;
                    
                       
                }
                /*
                printf("\nNow, the Marked Matrix is\n");
                printMatrix(markedMatrix, nRows, nCols);
                */
            }
        }
    }
    
    // Multiple solutions, just pick the first cell    
    if (found == FALSE) {
        while (marksExist(markedMatrix, nRows, nCols)) {
            
            for (i = 0; i < nRows; i++) {
                for (j = 0; j < nCols; j++) {
                    if (markedMatrix[i][j] == TRUE) {  
                        // Store answer in pArray
                        finalRank[i] = j;
                        // Set the entire row and column to 0 
                        // in markedMatrix
                        resetRowCol(markedMatrix, i, j, nRows, nCols);
                        break;
                    }
                }
            }                
        }
    }
}

// Function that checks if any marks left in markedMatrix
int marksExist(double **markedMatrix, int nRows, int nCols) {
    int i, j;
    for (i = 0; i < nRows; i++) {
        for (j = 0; j < nCols; j++) {
            if (markedMatrix[i][j] == 1) {
                return TRUE;
            }
        }                    
    }
    return FALSE;    
}

// Function that checks if the given cell is the only zero in its row
int onlyZeroInRow(double **markedMatrix, int nCols, int row, int col) {
    int j;
    for (j = 0; j < nCols; j++) {
        if (j != col &&
            markedMatrix[row][j] == 1) {
            return FALSE;
        }
    }
    return TRUE;
}

// Function that checks if the given cell is the only zero in its column
int onlyZeroInCol(double **markedMatrix, int nRows, int row, int col) {
    int i;
    for (i = 0; i < nRows; i++) {
        if (i != row &&
            markedMatrix[i][col] == 1) {
            return FALSE;
        }
    }
    return TRUE;
}


// Function that resets the specified row and column only
void resetRowCol(double **markedMatrix, int row, int col,
                 int nRows, int nCols) {    
    int i, j;
    for (i = 0; i < nRows; i++) {
        markedMatrix[i][col] = 0;
    }
    
    for (j = 0; j < nRows; j++) {
        markedMatrix[row][j] = 0;
    }
}

// Function that sums the final score for printing
void printFinalScore(int *finalRank, double **originalpScores, int numURLs) {
    double finalScore = 0;
    int i;
    for (i = 0; i < numURLs; i++) {            
        finalScore += originalpScores[i][finalRank[i]];
    }
    printf("%.6lf\n", finalScore);
}

// Function that prints the final rank
void printFinalRank(int *finalRank, int numURLs, char **arr) {
    int i;
    for (i = 0; i < numURLs; i++) {
        printf("%s\n", arr[finalRank[i]]);
    }
}

/*
// Function that prints a given double matrix
void printMatrix (double **matrix, int nRows, int nCols) {    
    int i = 0, j = 0;
    for(i=0;i<nRows;i++){
        for(j=0;j<nCols;j++){
            printf("%f ",matrix[i][j]);
        }
    printf("\n");
    }
}
*/
