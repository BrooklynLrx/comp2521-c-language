#include "footrule.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>


BSTree newBSTNode(char* store)
{
	BSTree new = malloc(sizeof(BST));
	assert(new != NULL);
	new->word = malloc(sizeof(char)*strlen(store)+1);
	
	strcpy(new->word,store);
	new->left = new->right = NULL;
	return new;
}

BSTree BSTreeInsert(BSTree t, char* v)
{
    
	if (t == NULL){
	    
		return newBSTNode(v);
	}
	else if (strcmp(t->word,v)<0){
		t->left = BSTreeInsert(t->left, v);
	}
	else if (strcmp(t->word,v)>0){
		t->right = BSTreeInsert(t->right, v);
	}
	else if (strcmp(t->word,v)==0){
	    return t;
	}
	return t;
}

void freeBSTree(BSTree t) {
    
	if (t == NULL) return;
	freeBSTree(t->left);
	freeBSTree(t->right);
	free(t->word);
	free(t);
}

urlnode createNode(char* url,int index){
    urlnode first = malloc (sizeof(struct node));
    first -> store = malloc(sizeof(char)*(1+strlen(url)));
    first -> pos = index;
    strcpy(first->store , url);
    first -> next =NULL;
    return first;

}

void freeURLNode(urlnode node) {
    urlnode tmp = node;
	while (node != NULL) {
	    tmp = node;
	    node = node->next;
	    free(tmp->store);
	    free(tmp);
	    
	}
}



int AddToArray(BSTree node, char** arr, int i)
{
     if(node == NULL){
          return i;
      }
     arr[i] = malloc(sizeof(char)* strlen(node->word)+1);
     
     strcpy(arr[i],node->word);
     
     i++;
     if(node->left != NULL){
          i = AddToArray(node->left, arr, i);
     }
     if(node->right != NULL){
          i = AddToArray(node->right, arr, i);
     }
     return i;
}


void showBSTreeNode(BSTree t)
{
	if (t == NULL) return;
	printf("%s\n",t->word);
	return;
}

// print values in prefix order
void BSTreePrefix(BSTree t)
{
	if (t == NULL){
	
	 return;
	}	
	BSTreePrefix(t->left);
	showBSTreeNode(t);
	BSTreePrefix(t->right);
}

int BSTreeNumNodes(BSTree Tree){
    if(Tree == NULL){
        return 0;
    }
    int left = BSTreeNumNodes(Tree->left);
    int right = BSTreeNumNodes(Tree -> right);
    return 1 + left+ right;
}


int get_Index(char**arr ,int size,char* find){
    int i = 0;
    while(i<size){
        if(strcmp(arr[i],find)==0){
            return i;        
        }
        i++;
    }
    return -1;
}
