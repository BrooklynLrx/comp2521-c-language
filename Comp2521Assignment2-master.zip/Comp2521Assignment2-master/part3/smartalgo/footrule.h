#ifndef FOOTRULE_H
#define FOORYKE_H

struct node {
    char* store;
    int pos;
    struct node* next;
};

typedef struct node* urlnode;

typedef struct BSTNode {
	char* word;
	struct BSTNode* left;
	struct BSTNode* right;
}BST;


typedef struct BSTNode *BSTree;


BSTree newBSTNode(char* store);


BSTree BSTreeInsert(BSTree t, char* v);
urlnode createNode(char* url,int index);
int AddToArray(BSTree node, char** arr, int i);
void freeBSTree(BSTree t);
void freeURLNode(urlnode node);

void showBSTreeNode(BSTree t);
void BSTreePrefix(BSTree t);

int BSTreeNumNodes(BSTree Tree);
int get_Index(char**arr ,int size,char* find);


#endif
