#include <stdlib.h>


int main(void){
    double** toBeCalculated = malloc(sizeof(double*)*5);
    int i ;
    for(i=0;i<5;i++){
        toBeCalculated[i] = malloc(sizeof(double)*4);
    }
    
    int row = 0, col = 0;
    while(row < 5){
        col = 0;
        while(col < 4){
            toBeCalculated[row][col]=0;
            col++;
        }        
        row++;
    }
    

}
