#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//Functions needed for PageRankW(d, diffPR, maxIterations)


//build function that read websites and Build structure using graph.h adt
    //will need to build on the current graphrep and add an array to hold page ranks
    
//function to calculate weight out not too hard if you use transitive closure
//function to calculate weight in
//function to calculate the total page rank of all incoming pages 
//function to calculate the page rank using the graph rep

//Gives the absolute difference of an array
double sumof(double* hold,double* store,int size){
    int i =0;
    double sum=0;
    while(i<size){
        sum=sum+fabs(hold[i]+store[i]);
        i++;
    }
    return sum;
}

int main (int argc, char** argv){
    //gets urls from collection.txt and puts it in a linked list
    if(argc<2){
        return 1;
    }
    
    //Creates a graph
    int size =nlinks();
    Graph g = newGraph(size);
    
    update_graph(g);
    
    //Input parameters
    double d = atof(argv[1]);
    double diffPR = atof(argv[2]);
    int maxIterations = atof(argv[3]);
    double rank = (double) 1/(double) size;
    int i = 0;
    
    //Arraay to calculate the diff
    double pr1[size];
    double pr2[size];
   
    while(i<size){
        pr1[i]=rank;
        pr2[i]=rank;
        give_rank(g,i, rank);
        i++;
    }
    
    int iteration = 0;
    double diff = diffPR;
    i = 0;
  
    int first = 0;


    while(iteration<maxIterations && diff>=diffPR){

        if(first == 0){
            diff=0;
            first = 1;
        }
        if(i==size){
            i=0;
        }
       

        iteration++;
        pr1[i] = g->matrix[i]->curr->pagerank;

        
        rank =((1-d)/size) + d*weightedPagerank(g,i);
        pr2[i]=rank;
        
        if(rank>1){
          //  printf("%s\n",g->matrix[i]->curr->url);
        }
        
        give_rank(g,i,rank);

        diff = sumof(pr1,pr2,size);

        i++;

    }

//Quicksort so its printed in order
quickSort(g , 0, g->nV-1);

print_to_pagerank(g);
  freeGraph(g) ;

}
