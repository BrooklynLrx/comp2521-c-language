#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "SearchTree.h" 
#include <assert.h>

struct node {
    char* url;
    double pagerank;
};

typedef struct node* urlnode;
typedef urlnode* list;

BSTree create_tree(BSTree words,BSTree links){
    if(words==NULL){
        return NULL;
    }
    FILE * file = fopen("invertedIndex.txt","r");
    char store[40];
   

    char buf[2000];
   
    assert(file!=NULL);
    char *url;
    while(fscanf(file,"%s",store)!=EOF){
       
       if(BSTreeCheck(words,store)==1){
           
            if (fgets(buf, 2000, file)) {
            //printf("buffer initially is %s\n", file);
            
            url = strtok(buf," ");
            // && strcmp(url,"\n") != 0
            while (url != NULL ) {
              //  printf("url is %s\n", url);
                //updateMembers(url, word, totalDocs, g);
                links = BSTreeInsert(links, url);
                url = strtok(NULL," \n");
             //   printf("buffer is %s\n", buf);
            }
          
          

       }

    
    }
    }
    fclose(file);
   assert(links!=NULL);
    return links;
}



int AddToArray(BSTree node, list arr, int i)
{
     if(node == NULL){
          return i;
      }
     arr[i] = malloc(sizeof(struct node));
     arr[i]->url = malloc(sizeof(char)* strlen(node->word)+1);
     
     strcpy(arr[i]->url,node->word);
     
     i++;
     if(node->left != NULL){
          i = AddToArray(node->left, arr, i);
     }
     if(node->right != NULL){
          i = AddToArray(node->right, arr, i);
     }
     return i;
}


int partition(list arr,int low , int high){
    double pivot = arr[high]->pagerank;
    int i = low-1;
    int j = low;
    urlnode hold;
    while(j<high){
        if(arr[j]->pagerank>=pivot){
            i++;
            hold = arr[j];
            arr[j] = arr[i];
            arr[i] = hold;
        }
    
    
        j++;
    }
    
    i++;
    hold = arr[j];
    arr[j] = arr[i];
    arr[i] = hold;
    return i;
}


void quicksort(list arr , int low ,int high){
    if(low>high){
        return;
    }
    int pi = partition(arr, low, high);
    quicksort(arr , low ,pi-1);
    quicksort(arr , pi+1,high);

}




int main (int argc , char** argv){
    
   BSTree words = newBSTree();
   BSTree links = newBSTree();
   int i = 1;
   while(i<argc){
        
        words=BSTreeInsert(words, argv[i]);
        i++;
   
   }
   
   assert(words!=NULL);
   links = create_tree(words, links);
   
    
    list finalurls = malloc(sizeof(urlnode)*BSTreeNumNodes(links));
    
    
    AddToArray(links, finalurls,0);
    i = 0;
    
   
    FILE * open = fopen("pagerankList.txt","r");
    char hold [500];
    while(i<BSTreeNumNodes(links)){
        while(fscanf(open,"%s",hold)!=EOF){
            if(strstr(hold,finalurls[i]->url)!=NULL){
                fscanf(open,"%s",hold);
                fscanf(open,"%s",hold);
                finalurls[i]->pagerank = atof(hold);
                break;
            }
        
        }
        rewind(open);
    
        i++;
    }
    i=0;
     quicksort(finalurls, 0,BSTreeNumNodes(links)-1);
    for(i=0;i<30;i++){
        printf("%s\n",finalurls[i]->url);
    
    }
    
    i = 0;
    while(i<BSTreeNumNodes(links)){
        free(finalurls[i]->url);
        free(finalurls[i]);
        i++;
    
    }
    free(finalurls);
    fclose(open);
    dropTree(words);
    dropTree(links);
}
