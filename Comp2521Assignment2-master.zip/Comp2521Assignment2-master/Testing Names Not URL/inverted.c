
#include <string.h>

#include "BSTree.h"
#include <stdio.h>

int main (){

    //Creates an inverted tree with words in alphabetical order
    BSTree tree = GetInverted();
    //This opens the text file and closes it so it clears what is written in
    FILE * clear = fopen("invertedIndex.txt","w");
    fclose(clear);
    //Prints it out
    BSTreeInfix(tree);
    //Frees the tree
    dropTree(tree);

}
