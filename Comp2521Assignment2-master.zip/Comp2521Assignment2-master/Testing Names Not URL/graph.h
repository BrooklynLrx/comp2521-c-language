// graph.h ... Interface to Graph of strings
// Written by John Shepherd, September 2015

#ifndef GRAPH_H
#define GRAPH_H


struct actualnode{
    char* url;
    double pagerank;
    int inlinks;
    int outlink;
    int index;
    struct actualnode* next;
};
typedef struct actualnode* node;



struct link{
    node curr;
    struct link* next;

};
typedef struct link* wrapper;


struct GraphRep {
    //number of vertices in the Graph
	int   nV;
	//actual nodes
	node firsturl;
	
	wrapper* matrix;
	//matrix for edges
};


typedef struct GraphRep *Graph;
void freeGraph(Graph g);
Graph newGraph(int maxV);
char* get_url(Graph g,int index);
int nlinks(void);
node create_node(char* urls );
wrapper create_wrapper(node store);
node node_list_read_urls(void);
node get_node(char* urls,Graph g);
void update_graph(Graph graph);
void showGraph(Graph g);
void give_rank(Graph g,int i,double rank);
double weightedPagerank(Graph g,int index);
void quickSort(Graph g , int low , int high);
void print_to_pagerank(Graph g);


#endif
