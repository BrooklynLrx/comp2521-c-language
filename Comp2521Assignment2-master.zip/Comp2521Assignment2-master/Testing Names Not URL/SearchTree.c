#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "SearchTree.h" 
#include <assert.h>




// make a new node containing a value

BSTree newBSTNode(char* store)
{
	BSTree new = malloc(sizeof(BST));
	assert(new != NULL);
	new->word = malloc(sizeof(char)*strlen(store)+1);
	
	strcpy(new->word,store);
	new->left = new->right = NULL;
	return new;
}

// create a new empty BSTree
BSTree newBSTree()
{
	return NULL;
}

int BSTreeNumNodes(BSTree Tree){
    if(Tree == NULL){
        return 0;
    }
    int left = BSTreeNumNodes(Tree->left);
    int right = BSTreeNumNodes(Tree -> right);
    return 1 + left+ right;

}


// free memory associated with BSTree
void dropBSTree(BSTree t)
{
	if (t == NULL) return;
	free(t->word);
	dropBSTree(t->left);
	dropBSTree(t->right);
	free(t);
}






// display BSTree root node
void showBSTreeNode(BSTree t)
{
	if (t == NULL) return;
	printf("%s\n",t->word);
	return;
}



// print values in prefix order
void BSTreePrefix(BSTree t)
{
	if (t == NULL){
	
	 return;
	}
	
	
	BSTreePrefix(t->left);
	showBSTreeNode(t);
	BSTreePrefix(t->right);
}








// insert a new value into a BSTree
BSTree BSTreeInsert(BSTree t, char* v)
{
    
	if (t == NULL){
	   
		return newBSTNode(v);
	}
	else if (strcmp(t->word,v)<0){
		t->left = BSTreeInsert(t->left, v);
	}
	else if (strcmp(t->word,v)>0){
		t->right = BSTreeInsert(t->right, v);
	}
	else if (strcmp(t->word,v)==0){
	    return t;
	}
	return t;
}


//checks the tree to see if a string is in a Tree

int BSTreeCheck(BSTree t, char* v)
{
    
	if (t == NULL){
	    
		return 0;
	}else if (strcmp(t->word,v)==0){
	   // printf("\n%s FINAL %s\n",t->word,v);
	    return 1;
	}
	else if (strcmp(t->word,v)<0){
	    //printf("\n%s FINAL\n",t->word);
	   // printf("%s FINALWORD\n",v);
		return BSTreeCheck(t->left, v);
	}
	else if (strcmp(t->word,v)>0){
	    return BSTreeCheck(t->right, v);
	}
	//printf("\n%s RIP\n",t->word);
	//printf("%s RIPWORD\n",v);
	return 0;
	
}


//Function that frees the tree
void dropTree(BSTree t){
    if(t==NULL){
        return;
    }
    free(t->word);
    dropTree(t->left);
    dropTree(t->right);
    free(t);
}





