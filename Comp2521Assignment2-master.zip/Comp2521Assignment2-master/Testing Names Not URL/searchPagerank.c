#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "SearchTree.h" 
#include <assert.h>

struct node {
    char* url;
    double pagerank;
};

typedef struct node* urlnode;
typedef urlnode* list;

//Function that given a BSTree with words and a BStree with links, creates a new BSTree with only the urls we need
BSTree create_tree(BSTree words,BSTree links){
    if(words==NULL){
        return NULL;
    }
    FILE * file = fopen("invertedIndex.txt","r");
    char store[50];
   

    char buf[2000];
   
    assert(file!=NULL);
    char *url;
    while(fscanf(file,"%s",store)!=EOF){
       //printf("%s store \n",store);
       if(BSTreeCheck(words,store)==1){
          // printf("dafs\n\n");
            if (fgets(buf, 2000, file)) {
            //printf("buffer initially is %s\n", file);
            
                url = strtok(buf," ");
                // && strcmp(url,"\n") != 0
                while (url != NULL ) {
                  //  printf("url is %s\n", url);
                    //updateMembers(url, word, totalDocs, g);
                    links = BSTreeInsert(links, url);
                    url = strtok(NULL," \n");
                 //   printf("buffer is %s\n", buf);
                }
              
    
            }

    
        }
    }
    fclose(file);
   assert(links!=NULL);
    return links;
}


//Function that given a BSTree
int BSTree_to_Array(BSTree node, list arr, int i)
{
     if(node == NULL){
          return i;
      }
     arr[i] = malloc(sizeof(struct node));
     arr[i]->url = malloc(sizeof(char)* strlen(node->word)+1);
     
     strcpy(arr[i]->url,node->word);
     
     i++;
     if(node->left != NULL){
          i = BSTree_to_Array(node->left, arr, i);
     }
     if(node->right != NULL){
          i = BSTree_to_Array(node->right, arr, i);
     }
     return i;
}



//Function that partitions for a quick sort
int partition(list arr,int low , int high){
    double pivot = arr[high]->pagerank;
    int i = low-1;
    int j = low;
    urlnode hold;
    while(j<high){
        if(arr[j]->pagerank>=pivot){
            i++;
            hold = arr[j];
            arr[j] = arr[i];
            arr[i] = hold;
        }
        j++;
    }
    
    i++;
    hold = arr[j];
    arr[j] = arr[i];
    arr[i] = hold;
    return i;
}

//Function that quick sorts a list 
void quicksort(list arr , int low ,int high){
    if(low>high){
        return;
    }
    int pi = partition(arr, low, high);
    quicksort(arr , low ,pi-1);
    quicksort(arr , pi+1,high);

}




int main (int argc , char** argv){
   if(argc==1){
        return 1;
   }
   
   BSTree words = newBSTree();
   BSTree links = newBSTree();
   int i = 1;
   
   //Inserts the words into a tree
   while(i<argc){

        words=BSTreeInsert(words, argv[i]);
        i++;
   
   }

   
   assert(words!=NULL);
   links = create_tree(words, links);
   
    
    list finalurls = malloc(sizeof(urlnode)*BSTreeNumNodes(links));
    
    
    BSTree_to_Array(links, finalurls,0);
    i = 0;
    i = 0;

    i=0;
    //Opens pageranklist.txt and finds the urls in a list array and updates them with their pagerank
    FILE * open = fopen("pagerankList.txt","r");
    char hold [500];
    while(i<BSTreeNumNodes(links)){
        while(fscanf(open,"%s",hold)!=EOF){
            if(strstr(hold,finalurls[i]->url)!=NULL){
                fscanf(open,"%s",hold);
                fscanf(open,"%s",hold);
                finalurls[i]->pagerank = atof(hold);
                break;
            }
        
        }
        rewind(open);
    
        i++;
    }
    i=0;
    
    //Quick sorts them and outputs them into terminal
     quicksort(finalurls, 0,BSTreeNumNodes(links)-1);
     
     
    for(i=0;i<BSTreeNumNodes(links);i++){
        if(i==30){
            break;
        }
        printf("%s\n",finalurls[i]->url);
    
    }
    
    i = 0;
    while(i<BSTreeNumNodes(links)){
        free(finalurls[i]->url);
        free(finalurls[i]);
        i++;
    
    }
    
    free(finalurls);
    fclose(open);
    dropTree(words);
    dropTree(links); 
}
