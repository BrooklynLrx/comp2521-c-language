// Graph.c ... Graph of strings (adjacency matrix)
// Written by John Shepherd, September 2015

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "graph.h"

#define strEQ(g,t) (strcmp((g),(t)) == 0)

node node_list_read_urls(void);
wrapper create_wrapper(node store);


//Function that takes the number of vertices and builds a Graph
Graph newGraph(int maxV)
{
	Graph new = malloc(sizeof(struct GraphRep));
	assert(new != NULL);
	int i = 0;
	new->nV = maxV;
	//create memory to hold all pointer to links
	new->firsturl = node_list_read_urls();
	
	new->matrix = malloc(sizeof(struct link)*maxV);
    node hold = new->firsturl; 
    
    while(hold!=NULL){
        new -> matrix[i] =create_wrapper(hold);
        i++;
        hold = hold->next;
	}
    
	return new;
}


//Function that returns the url given an index
char* get_url(Graph g,int index){
   
    return g->matrix[index] -> curr -> url;
}


//Function that returns the number of URLs in collection.txt
int nlinks(void){
    FILE * file= fopen("collection.txt","r");
    char store [50];
   
    fscanf(file,"%s",store);
   

    int i = 1;
    while(fscanf(file,"%s",store)!=EOF){
      

       
        i++;
       
    }
    fclose(file);
    return i;
}


// Function that Creates a Node
node create_node(char* urls) {
    node new = malloc(sizeof(struct actualnode));
    new -> url = malloc(sizeof(char)*strlen(urls)+1);
    strcpy(new -> url , urls);
    new -> pagerank = 0;
    new -> inlinks =0;
    new -> outlink =0;
    new -> index = 0;
    new -> next = NULL;
    return new;

}

//Function To create A wrapper 
wrapper create_wrapper(node store){
    wrapper new = malloc(sizeof(struct link));
    new -> curr = store;
    new -> next = NULL;
    return new;
}


//Opens Collection.txt and Creates nodes
node node_list_read_urls(void){
    FILE * file= fopen("collection.txt","r");
    char store [50];
    node first=NULL;
    node iterator=NULL;
    fscanf(file,"%s",store);
    first = create_node(store);
    first -> index = 0;
    iterator = first;
    int i = 1;
    while(fscanf(file,"%s",store)!=EOF){
      

        iterator -> next = create_node(store);
        iterator -> next -> index = i; 
        iterator = iterator -> next;
       
        i++;
       
    }
    
    fclose(file);
    return first;
    
}

//Function that returns the node given a URL
node get_node(char* urls,Graph g){
    node first = g->firsturl;
    while(first!=NULL){
        if(strcmp(first->url,urls)==0){
            return first;
        }
        first = first ->next;
    }
    return NULL;

}

//Update a Graph with its outgoing links
void update_graph(Graph graph){
    char open [50];
    char hold [50];
    int i = 0;
    FILE *fp;
    wrapper iterator;
    node store;
    
    while(i < graph -> nV){
        
        strcpy(open,graph ->matrix[i]->curr-> url);
        
        iterator = graph->matrix[i];
        
        strcat(open,".txt");
        fp = fopen(open,"r");
       
        while(fscanf(fp,"%s",hold)){
           // printf("%s\n",hold);
            if(strcmp(hold,"#start") == 0 || strcmp(hold,"Section-1") == 0 || strcmp(hold,graph -> matrix[i]->curr->url)==0){
                continue;
            }
        
            if(strcmp(hold,"#end")==0){
                break;
            }

            store = get_node(hold,graph);
            store -> inlinks++;
            graph ->matrix[i]->curr->outlink++;
            iterator -> next = create_wrapper(store);
            iterator = iterator -> next;
            
        }
            
        fclose(fp);
        i++;
    }


}

//Prints the Graph given.
void showGraph(Graph g){
    int i =0;
    wrapper first;
    while(i<g->nV){
        first = g->matrix[i];
        printf("inlinks %d outlinks %d pagerank %.7f  index %d ",first->curr->inlinks,first->curr->outlink,first->curr->pagerank,first->curr->index);
        while(first!=NULL){
            printf("%s -> ",first->curr->url);
            first = first->next;
        }
        printf("\n");
        i++;
        
    }
}

//Give a rank to a node
void give_rank(Graph g,int i,double rank){
    g->matrix[i]->curr->pagerank = rank;
    return;
}


//Gets the number of inlinks of a node
int get_in_links(Graph g,int i){
    return g->matrix[i]->curr->inlinks;
}


//Gets the number of inlinks of a node by reference
int get_in_links_of_reference(Graph g ,int i){
    wrapper first = g-> matrix[i];
    int links = 0;
    first = first -> next;
    while(first!=NULL){
        links = links + first -> curr -> inlinks;
        first=first->next;
    }
    return links;
}

//Gets the number of outlinks of a node
double get_outlinks(Graph g,int i){
    if(g->matrix[i]->curr->outlink == 0){
        return 0.5;
    }
    return g->matrix[i]->curr->outlink;
}


//Gets the number of outlinks of a node reference
double get_out_links_of_reference(Graph g,int i){
    wrapper first = g->matrix[i];
    double links=0;
   
    first = first -> next;
    while(first!=NULL){
        
        links = get_outlinks(g,first->curr->index) +links;
        first = first->next;
    }
    return links;
}

//Get weightedIn*weighted out

double get_weighted_in_out(Graph g,int first, int second){
    double weightout = get_outlinks(g,first)/(double)get_out_links_of_reference(g,second);
    double weightin = get_in_links(g,first)/(double)get_in_links_of_reference(g ,second);
    
   // printf("weightout %f\n",weightout);
    
  // printf("\nurlfirst %s , urlsecond %s\n",g->matrix[first]->curr->url,g->matrix[second]->curr->url);
    //printf("weightout %f\n",weightout);
    //printf("weightin %f\n",weightin);
    return weightout*weightin;
}

//Gets the Weighted Pagerank in the pagerank formula
double weightedPagerank(Graph g,int index){
    wrapper first;
    int i =0;
   
    double weight = 0;
    int counter = 0;
    wrapper hold ;
    while(i<g->nV){
        first = g->matrix[i];
        hold = first;
        if(i!=index && g->matrix[i]->curr->outlink>0){
                  
            while(first!=NULL ){
            
                //printf("\n%d link index %d\n",first->curr->index,index);   
                
                if(first->curr->index==index){
                    
                    weight=weight+hold->curr->pagerank*get_weighted_in_out(g, index,g->matrix[i]->curr ->index);//url is the rank we need ,
            //        printf("\n%s\n\n",hold->curr->url);
                    counter++;
                    
                    break;
                }
                first = first->next;
            }
        }
        i++;
        
    }
   // printf("%s url \n , weight %f\n\n" ,g->matrix[index]->curr->url,weight);
    
    return weight;

}

//Partition in a quick sort
int partition(Graph g , int low , int high){
    double pivot = g -> matrix[high]->curr->pagerank;
    int i = low -1;
    int j=low;
    wrapper hold;
    while(j<high){
        if(g->matrix[j]->curr->pagerank>=pivot){
        
            i++;
            hold = g->matrix[i];
            g->matrix[i] = g->matrix[j];
            g->matrix[j] = hold;
        }
        j++;
    }
    i++;
    hold = g->matrix[i];
    
    g->matrix[i] = g->matrix[j];
    g->matrix[j] = hold;
   
    return i;

}

//QuickSort the graph
void quickSort(Graph g , int low , int high){
    if(low<=high){
      int pi = partition(g, low, high);
        
        quickSort(g, low, pi - 1);  // Before pi
        quickSort(g, pi + 1, high); // After pi
    }



}

//Prints the pageranks to pagerankList.txt
void print_to_pagerank(Graph g){
    FILE* open = fopen("pagerankList.txt","w");
    int i =0;
    while(i<g->nV){
        fprintf(open,"%s, %d, %.7f\n",g->matrix[i]->curr->url,g->matrix[i]->curr->outlink , g->matrix[i]->curr->pagerank);
    
        i++;
    }
    fclose(open);

}



//Free Graph
void freeGraph(Graph g){
    int i = 0;
    wrapper hold;
    wrapper past;
    while(i<g->nV){
        hold = g -> matrix[i];
        while(hold->next!=NULL){
            past = hold;
            hold = hold->next;
            free(past);
        }
        free(hold);
        i++;
    }
    free(g->matrix);
    node first = g->firsturl;
    node store;
    while(first->next!=NULL){
        store = first;
        first = first -> next;
        free(store->url);
        free(store);
        
    }
    free(first->url);
    free(first);
    
    free(g);
}


