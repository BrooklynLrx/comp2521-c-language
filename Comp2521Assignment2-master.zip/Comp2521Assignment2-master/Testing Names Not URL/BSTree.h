// BSTree.h ... interface to binary search tree ADT
//This was adapted from cse documents
#ifndef BSTREE_H
#define BSTREE_H

struct word_node{
    struct word_node* next;
    char * store;

};


typedef struct word_node* words;


typedef struct BSTNode {
	char* word;
	words url;
	struct BSTNode* left;
	struct BSTNode* right;
}BST;


typedef struct BSTNode *BSTLink;

words create_node(char* hold);

typedef struct BSTNode *BSTree;

// create an empty BSTree
void dropTree(BSTree t);
BSTree newBSTree();
// free memory associated with BSTree
void dropBSTree(BSTree);
// display a BSTree
void showBSTree(BSTree);
// display BSTree root node


// print values in infix order
void BSTreeInfix(BSTree);

BSTree read_to_bsttree(BSTree t,char* url);

// count #nodes in BSTree
int BSTreeNumNodes(BSTree);
// count #leaves in BSTree
int BSTreeNumLeaves(BSTree);

// insert a new value into a BSTree
BSTree BSTreeInsert(BSTree t, char* v,char* url);
// check whether a value is in a BSTree

// delete a value from a BSTree

BSTree GetInverted(void);
int count_link(char* url);
words BSTreeFind(BSTree t, char* v);
words get_URL(void);
#endif













