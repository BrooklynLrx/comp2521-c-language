// BSTree.h ... interface to binary search tree ADT

#ifndef SEARCHTREE_H
#define SEARCHTREE_H

struct word_node{
    struct word_node* next;
    char * store;

};




typedef struct BSTNode {
	char* word;
	struct BSTNode* left;
	struct BSTNode* right;
}BST;






typedef struct BSTNode *BSTree;

// create an empty BSTree
BSTree newBSTree();
// free memory associated with BSTree
void dropBSTree(BSTree);
// display a BSTree
void showBSTree(BSTree);
// display BSTree root node

BSTree BSTreeInsert(BSTree t, char* v);
// print values in infix order
void BSTreeInfix(BSTree);
// print values in prefix order
void BSTreePrefix(BSTree);
// print values in postfix order
void BSTreePostfix(BSTree);
// print values in level-order
void BSTreeLevelOrder(BSTree);

BSTree read_to_bsttree(BSTree t,char* url);

// count #nodes in BSTree
int BSTreeNumNodes(BSTree);
// count #leaves in BSTree
int BSTreeNumLeaves(BSTree);
BSTree newBSTNode(char* store);
// insert a new value into a BSTree
BSTree BSTreeInsert(BSTree t, char* v);
// check whether a value is in a BSTree
void dropTree(BSTree t);
// delete a value from a BSTree
int BSTreeCheck(BSTree t, char* v);
BSTree GetInverted(void);
int count_link(char* url);

#endif













