// graph.h ... Interface to Graph of strings
// Written by John Shepherd, September 2015

#ifndef GRAPHAL_H
#define GRAPHAL_H

typedef struct NodeRepAl {
    char* url;
    double  totalWords;
    double  tfidf;
    int     numWordsFound;
    struct Node *next;
} NodeRepAl;

typedef struct NodeRepAl *NodeAl;

typedef struct GraphRepAl {
    NodeAl  *edges; // adjacency list
    int     nV;
    int     nE;
} GraphRepAl;

typedef struct GraphRepAl *GraphAl;

GraphAl newGraphAl();
NodeAl newNodeAl (char *url);
void fillGraphAl (GraphAl g);
void showGraphAl (GraphAl g);
void removeGraphAl (GraphAl g);

/*
void  disposeGraph(Graph g);
int   addEdge(Graph,char *src,char *dest);
int   nVertices(Graph g);
int isConnected(Graph g, char *src, char *dest);
int checkVertex(Graph g,char * src);
void showGraph(Graph g);
int addVertex(Graph g , char *src);
void give_rank(Graph graph,int index, double rank);
double get_pagerank(char* url,Graph g);
int get_in_links(Graph g, char* url);
double weightedPagerank(Graph g,char*url);
char* get_url(Graph g,int index);
*/

#endif
