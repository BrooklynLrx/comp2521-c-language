#ifndef HELPER_H
#define HELPER_H
//give a url finds the total amount of words
int count_total_words(char* url);

//given a url and a word, finds the frequency of the word
int count_appearances(char* url,char* word);

#endif
