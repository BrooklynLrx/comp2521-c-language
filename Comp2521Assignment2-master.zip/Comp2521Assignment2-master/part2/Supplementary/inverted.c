#include "read.h"
#include <string.h>
#include "graph.h"
#include "BSTree.h"
#include <stdio.h>

int main (){
    BSTree tree = GetInverted();
    test(tree);
}
