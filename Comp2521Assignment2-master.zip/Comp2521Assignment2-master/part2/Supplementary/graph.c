// Graph.c ... Graph of strings (adjacency matrix)
// Written by John Shepherd, September 2015

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "graph.h"

#define strEQ(g,t) (strcmp((g),(t)) == 0)

//unsigned char is int with a larger range

struct actualnode{
    struct actualnode* next;
    char* url;
    // we can just use the first index of the matrix to store page rank , will be too complicated to update subsequent ones
    double pagerank;
    int links;
};
typedef struct actualnode* node;


struct GraphRep {
    //number of vertices in the Graph
	int   nV;
	int   maxV;
	//actual nodes
	node *vertex;
	//matrix for edges
}GraphRep;


// newGraph()
// - create an initially empty Graph





Graph newGraph(int maxV)
{
	Graph new = malloc(sizeof(GraphRep));
	assert(new != NULL);
	int i, j;
	new->nV = 0;
	new->maxV = maxV;
	//create memory to hold all pointer to links
	new->vertex = malloc(maxV*sizeof(char *));
	assert(new->vertex != NULL);

	

	return new;
}

char* get_url(Graph g,int index){
    return g->vertex[index]->url;
}

int getlinks(Graph g , char* url){
    int i = 0;
    while(i< g->nV){
        if(strcmp(url,g->vertex[i]->url)==0){
            return g->vertex[i]->links;
        }
        i++;
    }
    return -1;
}


int get_in_links(Graph g, char* url){
    int i = 0;
    int counter = 0;
    node first;
    while(i< g->nV){
        first = g->vertex[i];
        if(strcmp(url,g->vertex[i]->url)!=0){
            first=first->next;
            while(first!=NULL){
                if(strcmp(url,first->url)==0){
                    counter++;
                    break;
                }
                first=first->next;
            }
        }
        i++;
    }
    return counter;
}


int get_in_links_of_reference(Graph g , char* url){

    int links = 0;
    node first;
    int i = 0;
    while(i<g->nV){
        if(strcmp(url,g->vertex[i]->url)==0){
            
            break;
        }
    
        i++;
    }
    first = g->vertex[i];
    first = first -> next;
    while(first != NULL){
        links = links + get_in_links(g,first->url);
        first=first->next;
    }
    return links;
}


double get_out_links(Graph g, char* url){
    int i = 0;
    while(i<g->nV){
        if(strcmp(url,g->vertex[i]->url)==0){
            
            break;  
        }
        i++;      
    }
    if(g->vertex[i]->links==0){
       
        return 0.5;
    }
    return g->vertex[i]->links;

}


double get_out_links_of_reference(Graph g , char* url){

    double links = 0;
    node first;
    int i = 0;
    while(i<g->nV){
        if(strcmp(url,g->vertex[i]->url)==0){
            
            break;
        }
    
        i++;
    }
    first = g->vertex[i];
    first = first -> next;
    while(first != NULL){
        links = links + get_out_links(g,first->url);
        first=first->next;
    }
    return links;
}

double get_weighted_in_out(Graph g,char*urlfirst , char* urlsecond){
    double weightout = get_out_links(g,urlfirst)/(double)get_out_links_of_reference(g,urlsecond);
    double weightin = get_in_links(g,urlfirst)/(double)get_in_links_of_reference(g , urlsecond);
    
   // printf("weightout %f\n",weightout);
   // printf("weightin %f\n",weightin);
    return weightout*weightin;
}


double weightedPagerank(Graph g,char*url){
    node first;
    int i =0;
    int store = 0;
    double weight = 0;
    while(i<g->nV){
        first = g->vertex[i];
        if(strcmp(g->vertex[i]->url,url)!=0){
            while(first!=NULL ){
                if(strcmp(first->url,url)==0){
                    printf("%s rank = %f\n",g->vertex[i]->url,get_pagerank(g->vertex[i]->url,g));
                    weight=weight+get_pagerank(g->vertex[i]->url,g)*get_weighted_in_out(g, url,g->vertex[i]->url);//url is the rank we need ,
                    break;
                }
                first = first->next;
            }
        }
        i++;
    }
    return weight;

}





double get_pagerank(char* url,Graph g){
    node first;
    int i = 0;
    while(i<g->nV){
        if(strcmp(url,g->vertex[i]->url)==0){
            return g->vertex[i]->pagerank;
        }
        i++;
    }
    return -1;
}

node create_graph_node(char* src){
    node first = malloc(sizeof(struct actualnode));
    first -> next = NULL;
    first -> pagerank = 0;
    first -> links =0;
    first -> url = malloc(sizeof(src));
    strcpy(first->url,src);
    return first;

}

// disposeGraph(Graph)
// - clean up memory associated with Graph
void disposeGraph(Graph g)
{
	if (g == NULL) return;
	int i;
	for (i = 0; i < g->nV; i++) {
		free(g->vertex[i]);
	}

}

// addEdge(Graph,Src,Dest)
// - add an edge from Src to Dest
// - returns 1 if edge successfully added
// - returns 0 if unable to add edge
//   (usually because nV exceeds maxV)
int addEdge(Graph g, char *src, char *dest)
{
    assert(g != NULL);
    int i = 0;
    int sourceindex = -1;
    while(i < g->nV){
        if(strcmp(src,g->vertex[i]->url)==0){
            sourceindex = i;
            break;
        }
        i++;
    }
    
    assert(sourceindex != -1);
    node first = g->vertex[sourceindex];
    first->links++;
    printf("add %d",first->links);
    while(first->next!=NULL){
        first=first->next;
    }
    first -> next = malloc(sizeof(struct actualnode));
    first->next->url = malloc(sizeof(dest));
    strcpy(first->next->url , dest);
    first -> next -> next = NULL;
    
    
	return 1;
}

// isConnected(Graph,Src,Dest)
// - check whether there is an edge from Src->Dest
int isConnected(Graph g, char *src, char *dest)
{
    assert(g != NULL);
    int i = 0;
    int sourceindex = -1;
    while(i < g->nV){
        if(strcmp(src,g->vertex[i]->url)==0){
            sourceindex = i;
        }
        i++;
    }
    
    assert(sourceindex != -1);
    node first = g->vertex[sourceindex];
    while(first != NULL || strcmp(first->url,dest) == 0){
        first = first ->next;
    }
    
    if(first == NULL){
        return 0;
    }
    return 1;
}

// nVertices(Graph)
// - return # vertices currently in Graph
int nVertices(Graph g)
{
	assert(g != NULL);
	return (g->nV);
}

//checks whether vertex is in the Graph
// returns the index
int checkVertex(Graph g,char * src){
    int i = 0;
    int sourceindex = -1;
    while(i < g->nV){
        if(strcmp(src,g->vertex[i]->url)==0){
            sourceindex = i;
        }
        i++;
    }
    return sourceindex;
}

// addVertex(Str,Names,N)
// return 0 if it's already in the Graph 
int addVertex(Graph g , char *src)
{
    if(checkVertex(g,src) != -1){
        return 0;
    }
    assert(g->nV +1 <= g->maxV);
	g -> vertex[g->nV] = malloc(sizeof(struct actualnode));
	g->vertex[g->nV] -> url = malloc(sizeof(src));
	strcpy(g->vertex[g->nV]->url , src);
	g ->vertex[g->nV] -> pagerank = 0;
	g ->vertex[g->nV] -> next = NULL;
	g->nV++;
	
}

void showGraph(Graph g){
    int i =0;
    node first;
    while(i < g->nV){
        first = g->vertex[i];
        printf("%.7f ",first->pagerank);
        printf("links = %d",first->links);
        while(first != NULL){
            printf("%s -> ",first->url);
            first = first->next;
        }
        printf("\n");
        i++;
    }
}

void give_rank(Graph graph,int index, double rank){
    graph ->vertex[index]->pagerank = rank;
    return;

}


void update_graph(Graph graph){
    char open [10];
    char hold [20];
    int i = 0;
    FILE *fp;
    node iterator;
    while(i < graph -> nV){
        strcpy(open,graph ->vertex[i]-> url);
        iterator = graph->vertex[i];
        strcat(open,".txt");
        fp = fopen(open,"r");
        while(fscanf(fp,"%s",hold)){
            if(strcmp(hold,"#start") == 0 || strcmp(hold,"Section-1") == 0 || strcmp(hold,graph -> vertex[i]->url)==0){
                continue;
            }
        
            if(strcmp(hold,"#end")==0){
                break;
            }
            graph->vertex[i]->links++;
            iterator -> next = create_graph_node(hold);
            iterator = iterator -> next;
            
        }
            
        
        i++;
    }


}


