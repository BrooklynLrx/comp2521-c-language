// graph.h ... Interface to Graph of strings
// Written by John Shepherd, September 2015

#ifndef GRAPH_H
#define GRAPH_H




typedef struct GraphRep *Graph;
void update_graph(Graph graph);
// Function signatures

Graph newGraph(int maxV);
void  disposeGraph(Graph g);
int   addEdge(Graph,char *src,char *dest);
int   nVertices(Graph g);
int isConnected(Graph g, char *src, char *dest);
int checkVertex(Graph g,char * src);
void showGraph(Graph g);
int addVertex(Graph g , char *src);
void give_rank(Graph graph,int index, double rank);
double get_pagerank(char* url,Graph g);
int get_in_links(Graph g, char* url);
double weightedPagerank(Graph g,char*url);
char* get_url(Graph g,int index);

#endif
