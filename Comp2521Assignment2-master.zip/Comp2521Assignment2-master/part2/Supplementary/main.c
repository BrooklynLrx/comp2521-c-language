#include "graph.h"

int main (void){
    Graph  graph = newGraph(6);
    addVertex(graph, "One");
    addVertex(graph , "Two");
    addVertex(graph , "Three");
    addVertex(graph , "Four");
    addVertex(graph , "Five");
    addEdge(graph,"One","Two");
    addEdge(graph,"One","Three");
    addEdge(graph,"Two","Three");
    showGraph(graph);
}
