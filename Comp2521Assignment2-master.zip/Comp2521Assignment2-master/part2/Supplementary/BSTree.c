#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "BSTree.h"
#include "Queue.h"
#include "read.h"
#include <assert.h>


typedef struct BSTNode *BSTLink;


typedef struct BSTNode {
	char* word;
	words url;
	BSTLink left, right;
} BSTNode;

// make a new node containing a value

BSTLink newBSTNode(char* store,char* url)
{
	BSTLink new = malloc(sizeof(BSTNode));
	assert(new != NULL);
	new->word = malloc(sizeof(store));
	new -> url = create_node(url);;
	strcpy(new->word,store);
	new->left = new->right = NULL;
	return new;
}

// create a new empty BSTree
BSTree newBSTree()
{
	return NULL;
}

// free memory associated with BSTree
void dropBSTree(BSTree t)
{
	if (t == NULL) return;
	free(t->word);
	dropBSTree(t->left);
	dropBSTree(t->right);
	free(t);
}



// display BSTree root node
void showBSTreeNode(BSTree t)
{
	if (t == NULL) return;
	printf(" %s \n", t->word);
	printf("%d frequency\n",get_frequency(t->url));
}



// print values in prefix order
void BSTreePrefix(BSTree t)
{
	if (t == NULL){
	
	 return;
	}
	showBSTreeNode(t);
	show(t->url);
	BSTreePrefix(t->left);
	BSTreePrefix(t->right);
}
BSTree read_to_bsttree(BSTree t,char* url){
    char open [10];
    char hold [20];
    int i = 0;
    char delim [10];
    const char s[5]=".,;?";
    FILE *fp;
    char* transfer;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");
    int iterator=0;
    while(fscanf(fp,"%s",hold)){
        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }
        if(strcmp(hold,"Section-2")!=0&&i==0){
          // printf("lmao %s\n",hold);
            continue;
        }
        
        if(strcmp(hold,"#end")==0&&i==1){
           
            break;
        }
        
       
          
        transfer = strtok(hold,s);
        //printf("fuhuhgdf\n");
        while(iterator<strlen(transfer)){
           
            transfer[iterator] = tolower(transfer[iterator]);
            iterator++;
        }
        iterator=0;
        t=BSTreeInsert(t,transfer,url);
        //printf("%s\n",transfer);
        

    }
    assert(t!=NULL);
    return t;           
        
       
}


BSTree GetInverted(void){
   
    words urls = get_URL();
    BSTree tree=NULL;
    while(urls!=NULL){
        tree=read_to_bsttree(tree,get_word_store(urls));
        urls = get_next_word(urls);
    } 
    return tree;
}



int count_link(char* url){
    char open [10];
    char hold [20];
    int i = 0;
    //confirm if there are more
    const char s[5]=".,;?!";
    FILE *fp;
    char* transfer;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");
    int iterator=0;
    int counter=0;
    while(fscanf(fp,"%s",hold)){
        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }
        //what does it 
        if(strcmp(hold,"Section-2")!=0&&i==0){
          // printf("lmao %s\n",hold);
            continue;
        }
        
        if(strcmp(hold,"#end")==0&&i==1){
           
            break;
        }
               
        counter++;


    }
    return counter;           
        
}

void test(BSTree t){
    printf("word \n%s",t->word);
    show(t->url);
}


// insert a new value into a BSTree
BSTree BSTreeInsert(BSTree t, char* v,char* url)
{
    
	if (t == NULL){
	    
		return newBSTNode(v,url);
	}
	else if (strcmp(t->word,v)<0){
		t->left = BSTreeInsert(t->left, v,url);
	}
	else if (strcmp(t->word,v)>0){
		t->right = BSTreeInsert(t->right, v,url);
	}
	else if (strcmp(t->word,v)==0){
	    add_to_end(t->url , url);
	}
	return t;
}

// check whether a value is in a BSTree
words BSTreeFind(BSTree t, char* v)
{
    assert(t==NULL);
    if(t == NULL){
        return 0;
    }
    if(strcmp(t->word,v)>0){
        BSTreeFind(t->right,v);
    }
    if(strcmp(t->word,v)<0){
        BSTreeFind(t->left,v);
    }
    if(strcmp(t->word,v)==0){
        return t->url;
    }
}
