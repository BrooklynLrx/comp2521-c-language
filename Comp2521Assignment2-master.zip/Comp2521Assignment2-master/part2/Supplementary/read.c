#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "graph.h"
#include <assert.h>
#include "read.h"
struct word_node{
    struct word_node* next;
    int frequency;
    char * store;
};


int get_frequency(words node){
    return node-> frequency;
}


words create_node(char* hold){
    words first= malloc(sizeof(struct word_node));
    first->store = malloc(strlen(hold));
    strcpy(first->store,hold);
    first->next = NULL;
 
    return first;
}

void add_to_end(words first , char* hold){
    int i =0;
   
    while(first->next!=NULL){
        if(strcmp(first->store,hold)==0){
            i=1;
            first->frequency++;
            return;
        }
        first = first -> next;
    
    }
    if(strcmp(first->store,hold)==0){
            first->frequency++;
            return;
        }
    
    if(i==0){
        words last = create_node(hold);
        printf("%s,url FIRST\n",hold);
        last -> frequency = 1;
        first -> next = last;
    }
}

void show(words first){
    while(first!=NULL){
        printf("%s -> ",first->store);
        printf(" %d frequency ",first->frequency);
        first = first->next;    
    }    
    printf("\n");
}


words get_next_word(words first){
    return first->next;
}

char* get_word_store(words first){
    if(first == NULL){
        return NULL;
    }
    
    char* value = malloc(sizeof(first->store)); 
    strcpy(value,first->store);
    return value;
}


words get_URL(void){
    FILE * file= fopen("collection.txt","r");
    char store [6];
    words first=NULL;
    words iterator=NULL;
    fscanf(file,"%s",store);
    first = create_node(store);
    iterator = first;
    int i = 0;
    while(fscanf(file,"%s",store)!=EOF){
      
        iterator -> next = create_node(store);
        iterator = iterator -> next;
        i++;
       
    }
    return first;
}



Graph read (words first){

    int i = 0;
    words hold = first;
    while(hold != NULL){
        i++;
        hold = hold -> next;
    }
    
    
    Graph graph = newGraph(i);
    words iterator = first;
    while(first!=NULL){
        
        addVertex(graph , first->store);
        first = first -> next;
    }
    
    words del;
    while(iterator != NULL){
        del = iterator;
        iterator = iterator ->next;
        free (del);   
    }    
    return graph;
}






