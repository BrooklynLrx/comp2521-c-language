#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "helper.h"

int count_total_words(char* url){
    char open [10];
    char hold [20];
    int i = 0;
    //confirm if there are more
    const char s[5]=".,;?!";
    FILE *fp;
    char* transfer;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");
    int iterator=0;
    int counter=0;
    while(fscanf(fp,"%s",hold)){
        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }
      
        if(strcmp(hold,"Section-2")!=0&&i==0){         
            continue;
        }
        
        if(strcmp(hold,"#end")==0&&i==1){           
            break;
        }        
        counter++;
    }
    return counter;           
        
}


int count_appearances(char* url,char* word){
    char open [10];
    char hold [20];
    int i = 0;
    const char s[5]=".,;?!";
    FILE *fp;
    char* transfer;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");
    int iterator=0;
    int counter=0;
    while(fscanf(fp,"%s",hold)){
        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }
        //is an interator to see if its not section-2 ,this is to make sure we start and end in the right place  
        if(strcmp(hold,"Section-2")!=0&&i==0){
          
            continue;
        }
        
        if(strcmp(hold,"#end")==0&&i==1){
           
            break;
        }
      
      
      //strips punctuation
       if(hold[strlen(hold)-1] == '.' || hold[strlen(hold)-1]==',' || hold[strlen(hold)-1]==';' || hold[strlen(hold)-1]=='?' || hold[strlen(hold)-1]=='!'){
        
            hold[strlen(hold)-1]='\0';
        }
      
     
     //makes the word lower case
        while(iterator<strlen(hold)){
         
            hold[iterator] = tolower(hold[iterator]);
            iterator++;
        }
       
        
        if(strcmp(word,hold)==0){
            counter++;
        
        }
        iterator=0;
 

    }
    return counter;           
        
}


