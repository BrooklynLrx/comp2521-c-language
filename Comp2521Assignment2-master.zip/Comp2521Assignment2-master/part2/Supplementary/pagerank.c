#include "graph.h"
#include <stdio.h>
#include <stdlib.h>
#include "read.h"
#include <math.h>
//Functions needed for PageRankW(d, diffPR, maxIterations)


//build function that read websites and Build structure using graph.h adt
    //will need to build on the current graphrep and add an array to hold page ranks
    
//function to calculate weight out not too hard if you use transitive closure
//function to calculate weight in
//function to calculate the total page rank of all incoming pages 
//function to calculate the page rank using the graph rep


double sumof(double* hold,double* store,int size){
    int i =0;
    double sum=0;
    while(i<size){
        sum=sum+hold[i]+store[i];
        i++;
    }
    return sum;
}
//GET RID OF LAST PUNCTUATION
int main (int argc, char** argv){
    //gets urls from collection.txt and puts it in a linked list
    words url = get_URL();
    //
    //gets the list and makes an adjacency list graph
    Graph graph = read(url);
    // from the list of url updates the graph with nodes connected to it
    update_graph(graph);
    
    double d = atof(argv[1]);
    double diffPR = atof(argv[2]);
    int maxIterations = atof(argv[3]);
    int size = nVertices(graph);
    double rank = (double) 1/(double) size;
    int i = 0;
    double pr1[nVertices(graph)];
    double pr2[nVertices(graph)];
    while(i<size){
        pr1[i]=rank;
        pr2[i]=rank;
        give_rank(graph,i, rank);
        i++;
    }
    int iteration = 0;
    double diff = diffPR;
    i = 0;
    double hold=0;
    int first = 0;
    while(iteration<maxIterations && diff>=diffPR){
        
        if(first == 0){
            diff=0;
            first = 1;
        }
        if(i==nVertices(graph)){
            i=0;
        }
        
        //printf("%d iteration\n",i);
        iteration++;
        pr1[i] = get_pagerank(get_url(graph,i),graph);
        
        
        rank =((1-d)/size) + d*weightedPagerank(graph,get_url(graph,i));
        pr2[i]=rank;
        give_rank(graph,i,rank);
        diff = sumof(pr1,pr2,nVertices(graph));
       // printf("%f diff\n",diff);
      //   printf("%d iteration\n",iteration);
      //  printf("wwww %f\n",hold);
        i++;
    
    }


    
    showGraph(graph);

}
