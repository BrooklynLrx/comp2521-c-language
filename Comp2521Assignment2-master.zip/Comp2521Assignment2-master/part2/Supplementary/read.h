#ifndef READ_H
#define READ_H
#include "graph.h"

typedef struct word_node* words;
words create_node(char* hold);
void show(words first);
words get_URL(void);
Graph read (words first);
char* get_word_store(words first);
words get_next_word(words first);
#endif
