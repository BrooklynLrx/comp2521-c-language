// GraphAl.c ... Adjacency list
// Written by Lucy Zhao, 2018

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "graphAl.h"

#define strEQ(g,t) (strcmp((g),(t)) == 0)

// Function that creates an empty Graph

GraphAl newGraphAl(int nV) {
	GraphAl new = malloc(sizeof(GraphRepAl));
	assert(new != NULL);
	
	new->edges = malloc(nV*sizeof(NodeAl));
	int i;
	for (i = 0; i < nV; i++) {
		new->edges[i] = NULL;
	}	
	new->nV = nV;
	new->nE = 0;
	return new;
}

// Function that creates a Node containing URL only
NodeAl newNodeAl (char *url) {
    NodeAl new = malloc(sizeof(NodeRepAl));            
	assert(new != NULL);
	
	new->url = malloc((strlen(url)+1)*sizeof(char));
	strcpy(new->url, url);
	new->totalWords = 0;
	new->tfidf = 0;
	new->numWordsFound = 0;
	return new;
}

// Function that removes a Graph
void removeGraphAl (GraphAl g) {
    int i;
    for (i = 0; i < g->nV; i++) {
        free(g->edges[i]->url);
        free(g->edges[i]);
    }
    free(g->edges);   
    free(g);
}

/*
typedef struct NodeRepAl {
    char* url;
    double  totalWords;
    double  tfidf;
    struct Node *next;
} NodeRepAl;

typedef struct NodeRepAl *NodeAl;

typedef struct GraphRepAl {
    NodeAl  *edges; // adjacency list
    int     nV;
    int     nE;
} GraphRepAl;

typedef struct GraphRepAl *GraphAl;
*/

// Function that fills the graph with URLs from collection.txt
void fillGraphAl (GraphAl g) {
    FILE *fp = fopen("collection.txt","r");
    char url[8];    
    int i = 0;
    
    while (fscanf(fp,"%s", url) != EOF) {
        NodeAl new = newNodeAl(url);
        g->edges[i] = new;
        i++;        
    }
    fclose(fp);
}

// Function that prints the graph array
void showGraphAl (GraphAl g) {
    assert(g != NULL);
    
    int i;
    for (i = 0; i < g->nV; i++) {
        if (g->edges[i] == NULL) {
            printf("g does not contain anything yet\n");
        } else {
            printf("g->edges[%d]->url is %s\n", i, g->edges[i]->url);
            printf("g->edges[%d]->totalWords is %lf\n", i, g->edges[i]->totalWords);
            printf("g->edges[%d]->tfidf is %lf\n", i, g->edges[i]->tfidf);
            printf("g->edges[%d]->numWordsFound is %d\n", i, g->edges[i]->numWordsFound);
            printf("\n");
        }
    }
}
