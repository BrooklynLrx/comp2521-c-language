#include "graphAl.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include <ctype.h>

#define TRUE    1
#define FALSE   0
#define MAX_WORD_LEN    50  // Longest word in the English dictionary is 45
#define MAX_URL_LEN     50  // Provided in assn2 forum comments by Ashesh
#define MAX_LINE_LEN    1000
/* Program that ranks pages based on the tfidf score

> What is the tdidf score?
    term frequency (tf) 
        = frequency of term in a file / total # of terms in the file
    inverse document frequency (idf)
        = log(total # of documents / # of documents containing the term)
    tfidf = tf * idf
   
> What are we provided?
    invertedIndex.txt , collection.txt

> What will be the input of this program?
    Search terms (words) as commandline arguments
    
> What is the output of this program?
    (To stdout)
    + Top 30 URLS the top 30 pages in descending order of:
        - # of search terms found and then within this
        - summed tf-idf values for all search terms per page
    + the corresponding tf-idf score per page in "%.6f" format
*/

// ******************* Section: Function Prototypes *******************

int countURLs (void);
double countTotalWords(char* url);
double countAppearances(char* url,char* word);
int urlToID(char *targetURL);
double countTotalDocs(char *word);
void getTfidf(char *word, int i, GraphAl g);
void updateMembers (char *url, char *word, double totalDocs, GraphAl g);
void printOrder(GraphAl g);

// ************************** Section: Main **************************
int main (int argc, char *argv[]){
    
    // Create an adjacency list containing all URLs from collection.txt
    int urlCount = countURLs();        
    GraphAl g = newGraphAl(urlCount);
    fillGraphAl(g);    
    
    // For each word in the command line
    int i;
    for (i = 1; i < argc; i++) {
        getTfidf(argv[i], i, g);        
    }
    printOrder(g);         
    // showGraphAl(g);
    removeGraphAl(g);
}

// ************************ Section: Functions ************************

// Function that prints in descending order of:
    // - # of search terms found and then within this, then
    // - summed tf-idf values for all search terms per page, then
    // - alphabetical
void printOrder(GraphAl g) {
    int numPrints = 0;
    int *printed = calloc(g->nV, sizeof(int));

    while (numPrints < 30 && numPrints < g->nV) {
        int i;
        int printID = 0;
        int maxWordsFound = -1;
        double largestTfidf = -1;
        for (i = 0; i < g->nV; i++) {
 
            // URLs not printed and have highest or equal no. of search terms found            
            if (printed[i] != TRUE &&
                g->edges[i]->numWordsFound >= maxWordsFound) {
                
                // If it has more number of words found
                if (g->edges[i]->numWordsFound > maxWordsFound) {
                    printID = i;
                    maxWordsFound = g->edges[i]->numWordsFound;
                    largestTfidf = g->edges[i]->tfidf;
                
                // If it only has the same number of words found
                // But has the largest uncontested tfidf score
                // Set it as printID
                } else if (g->edges[i]->tfidf > largestTfidf) {                
                    printID = i;
                    maxWordsFound = g->edges[i]->numWordsFound;
                    largestTfidf = g->edges[i]->tfidf;
                
                // If it has an equal tfidf score and
                } else if (g->edges[i]->tfidf == largestTfidf) {
                    
                    // It is first in the alphabet compared to curr printID or, 
                    // If not, the current printID has already been printed
                    if (strcmp(g->edges[i]->url,g->edges[printID]->url) < 0 ||
                       (strcmp(g->edges[i]->url,g->edges[printID]->url) < 0 &&
                       printed[printID] == TRUE)) {
                    
                        printID = i;
                        maxWordsFound = g->edges[i]->numWordsFound;
                        largestTfidf = g->edges[i]->tfidf;
                    }
                }
            }            
        }
        // Only print if one or more words
        if (g->edges[printID]->numWordsFound > 0) {
            printf("%s %.6lf\n", g->edges[printID]->url, g->edges[printID]->tfidf);
        }
        printed[printID] = TRUE;
        numPrints++;   
    }
    free(printed);
}

// Function that gets the tdidf score for each URL with a given word
void getTfidf(char *word, int i, GraphAl g) {
    
    // Find that word in invertedIndex.txt
    FILE *fp = fopen("invertedIndex.txt","r");
    assert(fp != NULL);
    char wordSearch[MAX_WORD_LEN + 1];
   
    int found = FALSE; 
    
    // We will either find the word and stop there or reach the end of text
    while (found != TRUE && fscanf(fp,"%s", wordSearch) != EOF) {
        if (strcmp(wordSearch,word) == 0) {
            found = TRUE;
        }
    }
    
    // If found, then update the subsequent URLs' total word and frequency count
    if (found == TRUE) {
        
        // Scan the subsequent URLs, checking that url is a substring
        double totalDocs = countTotalDocs(word);        
        
        char buf[MAX_LINE_LEN];
        if (fgets(buf, MAX_LINE_LEN, fp)) {
            char *url;
            url = strtok(buf," ");
            // && strcmp(url,"\n") != 0
            while (url != NULL ) {
                updateMembers(url, word, totalDocs, g);
                url = strtok(NULL," \n");
            }

        }
        
                
    } else {
        printf("%s does not exist in invertedIndex.txt\n",word);
    }
    fclose(fp);
}

// Function that updates totalWords, calculates tfidf and updates the GraphAl 
void updateMembers (char *url, char *word, double totalDocs, GraphAl g) {
    
    // Get the URL id
    int id = urlToID(url);
    
    // If the URL is valid (not -1)
    if (id != -1) {
        // Update the totalWords count IF not counted already
        if (g->edges[id]->totalWords == 0) {
            g->edges[id]->totalWords = countTotalWords(url);                    
        }                
        
        // Calculate tfidf and update members (tfidf and numWordsFound)
        double frequency = countAppearances(url,word);
        double tf = frequency/g->edges[id]->totalWords;
        double idf = log10(g->nV/totalDocs);
        g->edges[id]->tfidf += tf*idf;
        g->edges[id]->numWordsFound++;
        /*
        printf("For id %d\n frequency is %lf\n tf is %lf\n total docs is %lf\n g->nV is %d\n idf is %lf\n", id, frequency, tf, totalDocs, g->nV, idf);
        */
    }
} 

// Function that counts the total amount of URLs in which a word appears in
double countTotalDocs(char *word) {
    FILE *fp = fopen("invertedIndex.txt","r");
    char wordSearch[MAX_WORD_LEN + 1];
    while (fscanf(fp,"%s", wordSearch) != EOF) {           
        if (strcmp(word,wordSearch) == 0) {
            break;
        }
    }
    double urlCount = 0;
    char buf[MAX_LINE_LEN];    
    
    if (fgets(buf, MAX_LINE_LEN, fp)) {
        char *url;
        url = strtok(buf," ");
        // && strcmp(url,"\n") != 0
        while (url != NULL ) {
            urlCount++;
            url = strtok(NULL," \n");
        }
    }    
    fclose(fp);
    return urlCount;
}


// Function that takes an URL and returns the ID (for array indexing)
int urlToID(char *targetURL){
    FILE *fp = fopen("collection.txt","r");    
    char url[MAX_URL_LEN]; 
    int id = 0;
    int found = FALSE;
    
    while (fscanf(fp,"%s", url) != EOF) {
        if (strcmp(targetURL,url) == 0) {
            found = TRUE;
            fclose(fp);
            return id;
        }
        id++;        
    }
   
    if (found == FALSE) {
        fclose(fp);
        id = -1;
    }
    return id;
}

// Function that counts the total number of URLs
int countURLs (void) {
    FILE *fp = fopen("collection.txt","r");
    char url[MAX_URL_LEN];    
    int count = 0;
    
    while (fscanf(fp,"%s", url) != EOF) {
        count++;        
    }
    fclose(fp);
    return count;
}

// Function that counts the total number of words in a URL file
double countTotalWords(char* url) {
    char open [MAX_URL_LEN];
    char hold [MAX_WORD_LEN + 1];
    int i = 0;
    FILE *fp;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");
    
    double counter=0;
    while(fscanf(fp,"%s",hold)){        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }      
        if(strcmp(hold,"Section-2")!=0&&i==0){         
            continue;
        }        
        if(strcmp(hold,"#end")==0&&i==1){           
            break;
        }        
        counter++;
    }
    fclose(fp);
    return counter;                   
}

double countAppearances(char* url,char* word) {
    char open [MAX_URL_LEN];
    char hold [MAX_WORD_LEN + 1];
    int i = 0;
    FILE *fp;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");
    int iterator = 0;
    double counter = 0;
    while(fscanf(fp,"%s",hold)){
        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }
        //is an interator to see if its not section-2 ,this is to make sure we start and end in the right place  
        if(strcmp(hold,"Section-2")!=0&&i==0){          
            continue;
        }
        
        if(strcmp(hold,"#end")==0&&i==1){           
            break;
        }      
      
       //strips punctuation
       if (hold[strlen(hold)-1] == '.' || 
           hold[strlen(hold)-1]==',' || 
           hold[strlen(hold)-1]==';' || 
           hold[strlen(hold)-1]=='?' || 
           hold[strlen(hold)-1]=='!') {        
            
            hold[strlen(hold)-1]='\0';
       }    
       
       //makes the word lower case
        while(iterator<strlen(hold)){         
            hold[iterator] = tolower(hold[iterator]);
            iterator++;
        }
               
        if(strcmp(word,hold)==0){
            counter++;
        }
        iterator=0;
    }
    fclose(fp);
    return counter;           
}
