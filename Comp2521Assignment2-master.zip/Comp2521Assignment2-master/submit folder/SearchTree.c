#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "SearchTree.h" 
#include <assert.h>




// make a new node containing a value

BSTree newBSTNode1(char* store)
{
	BSTree new = malloc(sizeof(BST));
	assert(new != NULL);
	new->word = malloc(sizeof(char)*strlen(store)+1);
	
	strcpy(new->word,store);
	new->left = new->right = NULL;
	return new;
}

// create a new empty BSTree
BSTree newBSTree1()
{
	return NULL;
}

int BSTreeNumNodes1(BSTree Tree){
    if(Tree == NULL){
        return 0;
    }
    int left = BSTreeNumNodes1(Tree->left);
    int right = BSTreeNumNodes1(Tree -> right);
    return 1 + left+ right;

}


// free memory associated with BSTree
void dropBSTree1(BSTree t)
{
	if (t == NULL) return;
	free(t->word);
	dropBSTree1(t->left);
	dropBSTree1(t->right);
	free(t);
}






// display BSTree root node
void showBSTreeNode1(BSTree t)
{
	if (t == NULL) return;
	printf("%s\n",t->word);
	return;
}



// print values in infix order
void BSTreePrefix1(BSTree t)
{
	if (t == NULL){
	
	 return;
	}
	
	
	BSTreePrefix1(t->left);
	showBSTreeNode1(t);
	BSTreePrefix1(t->right);
}








// insert a new value into a BSTree
BSTree BSTreeInsert1(BSTree t, char* v)
{
    
	if (t == NULL){
	   
		return newBSTNode1(v);
	}
	else if (strcmp(t->word,v)<0){
		t->left = BSTreeInsert1(t->left, v);
	}
	else if (strcmp(t->word,v)>0){
		t->right = BSTreeInsert1(t->right, v);
	}
	else if (strcmp(t->word,v)==0){
	    return t;
	}
	return t;
}


//checks the tree to see if a string is in a Tree

int BSTreeCheck1(BSTree t, char* v)
{
    
	if (t == NULL){
	    
		return 0;
	}else if (strcmp(t->word,v)==0){
	   // printf("\n%s FINAL %s\n",t->word,v);
	    return 1;
	}
	else if (strcmp(t->word,v)<0){
	    //printf("\n%s FINAL\n",t->word);
	   // printf("%s FINALWORD\n",v);
		return BSTreeCheck1(t->left, v);
	}
	else if (strcmp(t->word,v)>0){
	    return BSTreeCheck1(t->right, v);
	}
	//printf("\n%s RIP\n",t->word);
	//printf("%s RIPWORD\n",v);
	return 0;
	
}


//Function that frees the tree
void dropTree1(BSTree t){
    if(t==NULL){
        return;
    }
    free(t->word);
    dropTree1(t->left);
    dropTree1(t->right);
    free(t);
}





