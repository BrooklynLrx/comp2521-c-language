#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "BSTree.h" 
#include <assert.h>
#include <ctype.h>




// make a new node containing a value

BSTLink newBSTNode2(char* store,char* url)
{
	BSTLink new = malloc(sizeof(struct BSTNode));
	assert(new != NULL);
	new->word = malloc(sizeof(char)*(strlen(store)+1));
	new -> url = create_node2(url);;
	strcpy(new->word,store);
	new->left = new->right = NULL;
	return new;
}

// create a new empty BSTree
BSTree newBSTree2()
{
	return NULL;
}

//Function that given a string returns a node containing it
words create_node2(char* hold){
    words first= malloc(sizeof(struct word_node));
    first -> store = malloc(sizeof(char)*(strlen(hold)+1));
    strcpy(first->store,hold);
    first -> next = NULL;
    return first;
}


//Function that prints out the strings inside the word linked list
void show2(words first){
    while(first!=NULL){
        printf("%s -> ",first->store);
        first = first->next;
    
    }    
    printf("\n");

}



//Gets the next node in a linked list
words get_next_word2(words first){
    return first->next;
}


//Given a node it returns a char* of what was in the array
char* get_word_store2(words first){
        if(first == NULL){
            return NULL;
        }
        
        char* value = malloc(sizeof(char)*(strlen(first->store)+1)); 
        strcpy(value,first->store);
        return value;
    }




// free memory associated with BSTree
void dropBSTree2(BSTree t)
{
	if (t == NULL) return;
	free(t->word);
	dropBSTree2(t->left);
	dropBSTree2(t->right);
	free(t);
}

//Opens collection.txt and returns a linked list with all the urls
words get_URL2(void){
    FILE * file= fopen("collection.txt","r");
    char store [50];
    words first=NULL;
    words iterator=NULL;
    fscanf(file,"%s",store);
    first = create_node2(store);
    iterator = first;
    int i = 0;
    while(fscanf(file,"%s",store)!=EOF){
      

        iterator -> next = create_node2(store);
        iterator = iterator -> next;
        i++;
       
    }
    fclose(file);
    return first;
}





// display BSTree root node
void showBSTreeNode2(BSTree t)
{
	if (t == NULL) return;
	FILE* open = fopen("invertedIndex.txt","a");
	fprintf(open,"%s ", t->word);
	words first = t->url;
	while(first != NULL){
	    fprintf(open,"%s ",first->store);
	    first = first->next;
	}
	fprintf(open,"\n");
	fclose(open);
	return;
}



// print values in Infix order
void BSTreeInfix2(BSTree t)
{
	if (t == NULL){
	
	 return;
	}
	
	
	BSTreeInfix2(t->right);
	showBSTreeNode2(t);
	BSTreeInfix2(t->left);
}

//Given a a url and a tree , this function inputs its words in the tree
BSTree read_to_bsttree2(BSTree t,char* url){
    char open [50];
    char hold [50];
    int i = 0;
    FILE *fp;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");
    int iterator=0;
    while(fscanf(fp,"%s",hold)){
        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }
        if(strcmp(hold,"Section-2")!=0&&i==0){
          // printf("lmao %s\n",hold);
            continue;
        }
        
        if(strcmp(hold,"#end")==0&&i==1){
           
            break;
        }
        
       
        if(hold[strlen(hold)-1] == '.' || hold[strlen(hold)-1] == ',' || hold[strlen(hold)-1] == ';' ||hold[strlen(hold)-1] == '?'){
            hold[strlen(hold)-1] = '\0';
        }  
        //printf("fuhuhgdf\n");
        while(iterator<strlen(hold)){
           
            hold[iterator] = tolower(hold[iterator]);
            iterator++;
        }
        
        iterator=0;
        t=BSTreeInsert2(t,hold,url);
       // printf("%s insert\n",t->word);
        

    }
    fclose(fp);
    assert(t!=NULL);
    return t;           
        
       
}



//Function that uses to functions above to create an inverted tree
BSTree GetInverted2(void){
   
    words urls = get_URL2();
    BSTree tree=NULL;
    words hold = urls;
    char* temp;
    while(urls!=NULL){
   //   printf("aasfd\n");
        temp = get_word_store2(urls);
        tree=read_to_bsttree2(tree,temp);
        free(temp);
    //printf("a\n");
        urls = urls->next;
    }
  //  printf("done\n");
    words past;
    while(hold->next!=NULL){
        past = hold;
        hold = hold -> next;
        free(past->store);
        free(past);
    }
    free(hold->store);
    free(hold);
    return tree;

}

//Function that returns the number of links in a URL
int count_link2(char* url){
    char open [10];
    char hold [20];
    int i = 0;
    //confirm if there are more
    FILE *fp;
    strcpy(open,url);
    strcat(open,".txt");
    fp = fopen(open,"r");

    int counter=0;
    while(fscanf(fp,"%s",hold)){
        
        if(strcmp(hold,"Section-2")==0&&i==0){
            i=1;
            continue;
        }
        //what does it 
        if(strcmp(hold,"Section-2")!=0&&i==0){
          // printf("lmao %s\n",hold);
            continue;
        }
        
        if(strcmp(hold,"#end")==0&&i==1){
           
            break;
        }
        
       
        counter++;


    }
    return counter;           
        
}


//Function that adds a url in alphabetical order to the coressponding word in a BSTree
void add_to_end2(BSTree t, char* hold){
    
   if(t->url == NULL){
        t-> url = create_node2(hold);
        return;
   }
   
   if(strcmp(t->url->store,hold)>0){
        words temp = t->url;
        t->url = create_node2(hold);
        t->url->next = temp;
        return;
   }
   if(strcmp(t->url->store,hold)==0){
     
        return;
   }
   
   
   if(t->url->next == NULL){
         if(strcmp(t->url->store,hold)==0){
     
            return;
         }
        if(strcmp(t->url->store,hold)>0){
            words temp = t->url;
            t->url = create_node2(hold);
            t->url->next = temp;
            return;
        }else{
            t->url->next = create_node2(hold);
            return;
        
        }
        
   }
   
   words first = t->url->next;

   words past = t->url;
   if(strcmp(hold,past->store)<0){
        t->url = create_node2(hold);
        t->url->next = first;
        return;
   }
   
   if(strcmp(first->store,hold)==0||strcmp(past->store,hold)==0){
     
        return;
   }
   

   
   while(first->next!=NULL){

        if(strcmp(first->store,hold)==0||strcmp(past->store,hold)==0){
     
            return;
        }
        if(strcmp(hold,past->store)>0&&strcmp(hold,first->store)<0){
            past->next = create_node2(hold);
            past->next->next = first;
            return;
        }
        past = past ->next;
        first = first -> next;
   
   }
   
   if(strcmp(first->store,hold)==0||strcmp(past->store,hold)==0){
     
        return;
   }
   if(strcmp(hold,first->store)>0){
        first -> next = create_node2(hold);
        return;
   }
   if(strcmp(hold,first->store)<0&&strcmp(hold,past->store)>0){
        past -> next = create_node2(hold);
        past -> next -> next = first;
        return;
   }
 
   
}



// insert a new value into a BSTree
BSTree BSTreeInsert2(BSTree t, char* v,char* url)
{
    
	if (t == NULL){
	    
		return newBSTNode2(v,url);
	}
	else if (strcmp(t->word,v)<0){
		t->left = BSTreeInsert2(t->left, v,url);
	}
	else if (strcmp(t->word,v)>0){
		t->right = BSTreeInsert2(t->right, v,url);
	}
	else if (strcmp(t->word,v)==0){
	    add_to_end2(t, url);
	}
	return t;
}

// check whether a value is in a BSTree
words BSTreeFind2(BSTree t, char* v)
{
    assert(t==NULL);
    if(t == NULL){
        return 0;
    }
    if(strcmp(t->word,v)>0){
        BSTreeFind2(t->right,v);
    }
    if(strcmp(t->word,v)<0){
        BSTreeFind2(t->left,v);
    }
    if(strcmp(t->word,v)==0){
        return t->url;
    }
    return NULL;
}

//Frees a BSTree
void dropTree2(BSTree t){
    if(t==NULL){
        return;
    }
    words past;
    words curr = t->url;
    while(curr->next!=NULL){
        past = curr;
         curr = curr -> next;
        free(past->store);
        free(past);
       
    
    }
    free(curr->store);
    free(curr);
    free(t->word);
    dropTree2(t->left);
    dropTree2(t->right);
    free(t);
}
