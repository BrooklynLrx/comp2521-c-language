#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "SearchTree.h" 
#include <assert.h>

struct node {
    char* url;
    double pagerank;
};

typedef struct node* urlnode;
typedef urlnode* list;

//Function that given a BSTree with words and a BStree with links, creates a new BSTree with only the urls we need
BSTree create_tree1(BSTree words,BSTree links){
    if(words==NULL){
        return NULL;
    }
    FILE * file = fopen("invertedIndex.txt","r");
    char store[50];
   

    char buf[2000];
   
    assert(file!=NULL);
    char *url;
    while(fscanf(file,"%s",store)!=EOF){
       //printf("%s store \n",store);
       if(BSTreeCheck1(words,store)==1){
          // printf("dafs\n\n");
            if (fgets(buf, 2000, file)) {
            //printf("buffer initially is %s\n", file);
            
                url = strtok(buf," ");
                // && strcmp(url,"\n") != 0
                while (url != NULL ) {
                  //  printf("url is %s\n", url);
                    //updateMembers(url, word, totalDocs, g);
                    links = BSTreeInsert1(links, url);
                    url = strtok(NULL," \n");
                 //   printf("buffer is %s\n", buf);
                }
              
    
            }

    
        }
    }
    fclose(file);
   assert(links!=NULL);
    return links;
}


//Function that given a BSTree
int BSTree_to_Array1(BSTree node, list arr, int i)
{
     if(node == NULL){
          return i;
      }
     arr[i] = malloc(sizeof(struct node));
     arr[i]->url = malloc(sizeof(char)* strlen(node->word)+1);
     
     strcpy(arr[i]->url,node->word);
     
     i++;
     if(node->left != NULL){
          i = BSTree_to_Array1(node->left, arr, i);
     }
     if(node->right != NULL){
          i = BSTree_to_Array1(node->right, arr, i);
     }
     return i;
}



//Function that partitions for a quick sort
int partition1(list arr,int low , int high){
    double pivot = arr[high]->pagerank;
    int i = low-1;
    int j = low;
    urlnode hold;
    for(j = low ; j<= high -1 ;j++){
        if(arr[j]->pagerank>pivot){
            i++;
            hold = arr[j];
            arr[j]=arr[i];
            arr[i]=hold;
        }
    
    }
    
   
    hold = arr[high];
    arr[high] = arr[i+1];
    arr[i+1] = hold;
    return i+1;
}

//Function that quick sorts a list 
void quicksort1(list arr , int low ,int high){
    if(low>high){
        return;
    }
    int pi = partition1(arr, low, high);
    quicksort1(arr , low ,pi-1);
    quicksort1(arr , pi+1,high);

}




int main (int argc , char** argv){
   if(argc==1){
        return 1;
   }
   
   BSTree words = newBSTree1();
   BSTree links = newBSTree1();
   int i = 1;
   
   //Inserts the words into a tree
   while(i<argc){

        words=BSTreeInsert1(words, argv[i]);
        i++;
   
   }

   
   assert(words!=NULL);
   links = create_tree1(words, links);
   
    
    list finalurls = malloc(sizeof(urlnode)*BSTreeNumNodes1(links));
    
    
    BSTree_to_Array1(links, finalurls,0);
    i = 0;
    i = 0;

    i=0;
    //Opens pageranklist.txt and finds the urls in a list array and updates them with their pagerank
    FILE * open = fopen("pagerankList.txt","r");
    char hold [500];
    while(i<BSTreeNumNodes1(links)){
        while(fscanf(open,"%s",hold)!=EOF){
            if(strstr(hold,finalurls[i]->url)!=NULL){
                fscanf(open,"%s",hold);
                fscanf(open,"%s",hold);
                finalurls[i]->pagerank = atof(hold);
                break;
            }
        
        }
        rewind(open);
    
        i++;
    }
    i=0;
    
    //Quick sorts them and outputs them into terminal
     quicksort1(finalurls, 0,BSTreeNumNodes1(links)-1);
     
     
    for(i=0;i<BSTreeNumNodes1(links)&&i<30;i++){
     
        printf("%s\n",finalurls[i]->url);
    
    }
    
    i = 0;
    while(i<BSTreeNumNodes1(links)){
        free(finalurls[i]->url);
        free(finalurls[i]);
        i++;
    
    }
    
    free(finalurls);
    fclose(open);
    dropTree1(words);
    dropTree1(links); 
}
