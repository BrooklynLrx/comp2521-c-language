// BSTree.h ... interface to binary search tree ADT
//This was adapted from cse documents
#ifndef BSTREE_H
#define BSTREE_H

struct word_node{
    struct word_node* next;
    char * store;

};


typedef struct word_node* words;


typedef struct BSTNode {
	char* word;
	words url;
	struct BSTNode* left;
	struct BSTNode* right;
}BST;


typedef struct BSTNode *BSTLink;

words create_node2(char* hold);

typedef struct BSTNode *BSTree;

// create an empty BSTree
void dropTree2(BSTree t);
BSTree newBSTree2();
// free memory associated with BSTree
void dropBSTree2(BSTree);
// display a BSTree
void showBSTree2(BSTree);
// display BSTree root node


// print values in infix order
void BSTreeInfix2(BSTree);

BSTree read_to_bsttree2(BSTree t,char* url);

// count #nodes in BSTree
int BSTreeNumNodes2(BSTree);
// count #leaves in BSTree
int BSTreeNumLeaves2(BSTree);

// insert a new value into a BSTree
BSTree BSTreeInsert2(BSTree t, char* v,char* url);
// check whether a value is in a BSTree

// delete a value from a BSTree

BSTree GetInverted2(void);
int count_link2(char* url);
words BSTreeFind2(BSTree t, char* v);
words get_URL2(void);
#endif













