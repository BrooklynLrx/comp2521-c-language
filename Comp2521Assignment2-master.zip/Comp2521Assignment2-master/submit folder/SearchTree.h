// BSTree.h ... interface to binary search tree ADT

#ifndef SEARCHTREE_H
#define SEARCHTREE_H

struct word_node{
    struct word_node* next;
    char * store;

};




typedef struct BSTNode {
	char* word;
	struct BSTNode* left;
	struct BSTNode* right;
}BST;






typedef struct BSTNode *BSTree;

// create an empty BSTree
BSTree newBSTree1();
// free memory associated with BSTree
void dropBSTree1(BSTree);
// display a BSTree
void showBSTree1(BSTree);
// display BSTree root node

BSTree BSTreeInsert1(BSTree t, char* v);
// print values in infix order
void BSTreeInfix1(BSTree);
// print values in prefix order
void BSTreePrefix1(BSTree);
// print values in postfix order
void BSTreePostfix1(BSTree);
// print values in level-order
void BSTreeLevelOrder1(BSTree);

BSTree read_to_bsttree1(BSTree t,char* url);

// count #nodes in BSTree
int BSTreeNumNodes1(BSTree);
// count #leaves in BSTree
int BSTreeNumLeaves1(BSTree);
BSTree newBSTNode1(char* store);
// insert a new value into a BSTree
BSTree BSTreeInsert1(BSTree t, char* v);
// check whether a value is in a BSTree
void dropTree1(BSTree t);
// delete a value from a BSTree
int BSTreeCheck1(BSTree t, char* v);
BSTree GetInverted1(void);
int count_link1(char* url);

#endif













